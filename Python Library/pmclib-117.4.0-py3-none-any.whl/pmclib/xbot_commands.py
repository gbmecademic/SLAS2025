from PMCLIB import XBotCommands as _bot
from PMCLIB import PMCRTN
import PMCLIB
from System import Enum
from System import UInt16
from pmclib import pmc_types as pm
from pmclib.pmc_types import assert_type
from typing import List

__bot = _bot()


def activate_xbots():
	"""Activate all Xbots

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	

	rtn = __bot.ActivateXBOTS()

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"activate_xbots command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def deactivate_xbots():
	"""Deactivate all Xbots

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	

	rtn = __bot.DeactivateXBOTS()

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"deactivate_xbots command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def levitation_command(
	xbot_id: int = None,
	lev_mode: pm.LEVITATEOPTIONS = None,
	lev_speed: pm.LEVITATIONSPEED = None,
	force: float = None
):
	"""Levitate or land Xbot(s)

	Parameters
	----------
		Option 1
		------------
		xbot_id: int
			0 = all XBots, otherwise, XBot ID of a single XBot
		lev_mode: pm.LEVITATEOPTIONS
			0 = land, 1 = levitate,
		Option 2
		------------
		xbot_id: int
			0 = all XBots, otherwise, XBot ID of a single XBot
		lev_mode: pm.LEVITATEOPTIONS
			0 = land, 1 = levitate,
		lev_speed: pm.LEVITATIONSPEED
			specifies the speed at which the xbot levitate/land
		force: float
			z force after landing [N]
		Option 3
		------------
		xbot_id: int
			0 = all XBots, otherwise, XBot ID of a single XBot
		lev_mode: pm.LEVITATEOPTIONS
			0 = land, 1 = levitate,
		lev_speed: pm.LEVITATIONSPEED
			specifies the speed at which the xbot levitate/land

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	
	provided_args = {key for key, value in locals().items() if value is not None}
	
	allowed_combination = [
		frozenset({'xbot_id','lev_mode'}),
		frozenset({'xbot_id','lev_mode','lev_speed','force'}),
		frozenset({'xbot_id','lev_mode','lev_speed'})
	]

	if provided_args not in allowed_combination:
		raise ValueError("Invalid combinations of arguments")

	combination = 1
	for combos in allowed_combination:
		if provided_args != combos: combination += 1
		else:
			break
	
	if combination == 1:
		assert_type(xbot_id, int, "xbot_id")
		assert_type(lev_mode, pm.LEVITATEOPTIONS, "lev_mode")
	
		lev_mode_enum = PMCLIB.LEVITATEOPTIONS(lev_mode)


		rtn = __bot.LevitationCommand(int(xbot_id),lev_mode_enum)

	elif combination == 2:
		assert_type(xbot_id, int, "xbot_id")
		assert_type(lev_mode, pm.LEVITATEOPTIONS, "lev_mode")
		assert_type(lev_speed, pm.LEVITATIONSPEED, "lev_speed")
		assert_type(force, float, "force")
	
		lev_mode_enum = PMCLIB.LEVITATEOPTIONS(lev_mode)
		lev_speed_enum = PMCLIB.LEVITATIONSPEED(lev_speed)


		rtn = __bot.LevitationCommand(int(xbot_id),lev_mode_enum,lev_speed_enum,float(force))

	elif combination == 3:
		assert_type(xbot_id, int, "xbot_id")
		assert_type(lev_mode, pm.LEVITATEOPTIONS, "lev_mode")
		assert_type(lev_speed, pm.LEVITATIONSPEED, "lev_speed")
	
		lev_mode_enum = PMCLIB.LEVITATEOPTIONS(lev_mode)
		lev_speed_enum = PMCLIB.LEVITATIONSPEED(lev_speed)


		rtn = __bot.LevitationCommand(int(xbot_id),lev_mode_enum,lev_speed_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"levitation_command command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def mobility_control(
	xbot_id: int,
	mobility_mode: pm.MOBILITYOPTIONS
):
	"""Disable, land, or levitate the XBOT(s), deprecated

	Parameters
	----------
	xbot_id: int
		0 = all XBots, otherwise, XBot ID of a single XBot
	mobility_mode: pm.MOBILITYOPTIONS
		0 = disable, 1 = land, 2 = levitate

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(xbot_id, int, "xbot_id")
	assert_type(mobility_mode, pm.MOBILITYOPTIONS, "mobility_mode")
	
	mobility_mode_enum = PMCLIB.MOBILITYOPTIONS(mobility_mode)


	rtn = __bot.MobilityControl(int(xbot_id),mobility_mode_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"mobility_control command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def linear_motion_si(
	cmd_label: int,
	xbot_id: int,
	position_mode: pm.POSITIONMODE,
	path_type: pm.LINEARPATHTYPE,
	target_xmeters: float,
	target_ymeters: float,
	final_speed_meters_ps: float,
	max_speed_meters_ps: float,
	max_acceleration_meters_ps2: float
):
	"""linear motion command using SI units (meters, radians)

	Parameters
	----------
	cmd_label: int
		2 byte command label, converted to unsigned short
	xbot_id: int
		xbot ID
	position_mode: pm.POSITIONMODE
		0 = absolute position mode; 1 = relative position mode
	path_type: pm.LINEARPATHTYPE
		0 = direct; 1 = X then Y; 2 = Y then X
	target_xmeters: float
		Target Position X, in meters
	target_ymeters: float
		Target Position Y, in meters
	final_speed_meters_ps: float
		Final speed, in m/s
	max_speed_meters_ps: float
		Max speed, in m/s
	max_acceleration_meters_ps2: float
		Max acceleration, in m/s^2

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(cmd_label, int, "cmd_label")
	assert_type(xbot_id, int, "xbot_id")
	assert_type(position_mode, pm.POSITIONMODE, "position_mode")
	assert_type(path_type, pm.LINEARPATHTYPE, "path_type")
	assert_type(target_xmeters, float, "target_xmeters")
	assert_type(target_ymeters, float, "target_ymeters")
	assert_type(final_speed_meters_ps, float, "final_speed_meters_ps")
	assert_type(max_speed_meters_ps, float, "max_speed_meters_ps")
	assert_type(max_acceleration_meters_ps2, float, "max_acceleration_meters_ps2")
	
	position_mode_enum = PMCLIB.POSITIONMODE(position_mode)
	path_type_enum = PMCLIB.LINEARPATHTYPE(path_type)


	rtn = __bot.LinearMotionSI(UInt16(cmd_label),int(xbot_id),position_mode_enum,path_type_enum,float(target_xmeters),float(target_ymeters),float(final_speed_meters_ps),float(max_speed_meters_ps),float(max_acceleration_meters_ps2))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"linear_motion_si command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		rtn.TravelTimeSecs



def linear_single_axis_motion_si(
	cmd_label: int,
	xbot_id: int,
	position_mode: pm.POSITIONMODE,
	axis: pm.AXISNAMES,
	target_pos: float,
	final_speed: float,
	max_speed: float,
	max_acceleration: float,
	has_priority: bool
):
	"""Single axis linear point to point motion

	Parameters
	----------
	cmd_label: int
		2 byte command label, converted to unsigned short
	xbot_id: int
		xbot ID
	position_mode: pm.POSITIONMODE
		0 = absolute position mode; 1 = relative position mode
	axis: pm.AXISNAMES
		Which axis to move
	target_pos: float
		Target position of the axis (in m or rad)
	final_speed: float
		Final speed, in m/s or rad/s
	max_speed: float
		Max speed, in m/s or rad/s
	max_acceleration: float
		Max acceleration, in m/s^2 or rad/s^2
	has_priority: bool
		If "true" the command will have priority for the obtacle handling. A fence will be created around the motion path.

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(cmd_label, int, "cmd_label")
	assert_type(xbot_id, int, "xbot_id")
	assert_type(position_mode, pm.POSITIONMODE, "position_mode")
	assert_type(axis, pm.AXISNAMES, "axis")
	assert_type(target_pos, float, "target_pos")
	assert_type(final_speed, float, "final_speed")
	assert_type(max_speed, float, "max_speed")
	assert_type(max_acceleration, float, "max_acceleration")
	assert_type(has_priority, bool, "has_priority")
	
	position_mode_enum = PMCLIB.POSITIONMODE(position_mode)
	axis_enum = PMCLIB.AXISNAMES(axis)


	rtn = __bot.LinearSingleAxisMotionSI(int(cmd_label),int(xbot_id),position_mode_enum,axis_enum,float(target_pos),float(final_speed),float(max_speed),float(max_acceleration),bool(has_priority))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"linear_single_axis_motion_si command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		rtn.TravelTimeSecs



def arc_motion_meters_radians(
	cmd_label: int,
	xbot_id: int,
	arc_mode: pm.ARCMODE,
	arc_type: pm.ARCTYPE,
	arc_dir: pm.ARCDIRECTION,
	position_mode: pm.POSITIONMODE,
	x_meters: float,
	y_meters: float,
	final_speed_meters_ps: float,
	max_speed_meters_ps: float,
	max_acceleration_meters_ps2: float,
	radius_meters: float,
	angle_radians: float
):
	"""Arc motion command, in microns and millidegrees

	Parameters
	----------
	cmd_label: int
		2 byte command label, converted to unsigned short
	xbot_id: int
		xbot ID
	arc_mode: pm.ARCMODE
		0 = target + radius; 1 = center + angle
	arc_type: pm.ARCTYPE
		0 = minor arc; 1 = major arc
	arc_dir: pm.ARCDIRECTION
		0 = clockwise, 1 = counterclockwise
	position_mode: pm.POSITIONMODE
		0 = absolute position mode; 1 = relative position mode; for specifying the arc center
	x_meters: float
		target or center x position, meters
	y_meters: float
		target or center y position, meters
	final_speed_meters_ps: float
		final speed on exiting arc motion, m/s
	max_speed_meters_ps: float
		max tangential speed during arc motion, m/s
	max_acceleration_meters_ps2: float
		Max acceleration, in m/s^2
	radius_meters: float
		radius of arc in target + radius mode, meters
	angle_radians: float
		angle of rotation in center + angle mode, radians

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(cmd_label, int, "cmd_label")
	assert_type(xbot_id, int, "xbot_id")
	assert_type(arc_mode, pm.ARCMODE, "arc_mode")
	assert_type(arc_type, pm.ARCTYPE, "arc_type")
	assert_type(arc_dir, pm.ARCDIRECTION, "arc_dir")
	assert_type(position_mode, pm.POSITIONMODE, "position_mode")
	assert_type(x_meters, float, "x_meters")
	assert_type(y_meters, float, "y_meters")
	assert_type(final_speed_meters_ps, float, "final_speed_meters_ps")
	assert_type(max_speed_meters_ps, float, "max_speed_meters_ps")
	assert_type(max_acceleration_meters_ps2, float, "max_acceleration_meters_ps2")
	assert_type(radius_meters, float, "radius_meters")
	assert_type(angle_radians, float, "angle_radians")
	
	arc_mode_enum = PMCLIB.ARCMODE(arc_mode)
	arc_type_enum = PMCLIB.ARCTYPE(arc_type)
	arc_dir_enum = PMCLIB.ARCDIRECTION(arc_dir)
	position_mode_enum = PMCLIB.POSITIONMODE(position_mode)


	rtn = __bot.ArcMotionMetersRadians(UInt16(cmd_label),int(xbot_id),arc_mode_enum,arc_type_enum,arc_dir_enum,position_mode_enum,float(x_meters),float(y_meters),float(final_speed_meters_ps),float(max_speed_meters_ps),float(max_acceleration_meters_ps2),float(radius_meters),float(angle_radians))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"arc_motion_meters_radians command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		rtn.TravelTimeSecs



def sync_motion_si(
	xbot_count: int,
	xbot_ids: List[int],
	targets_x_meters: List[float],
	targets_y_meters: List[float],
	final_speeds_meters_ps: List[float],
	max_speeds_meters_ps: List[float],
	max_acceleration_meters_ps2: List[float]
):
	"""synchronous motion command

	Parameters
	----------
	xbot_count: int
		number of xbots specified in this command. valid range is 1 to 4
	xbot_ids: List[int]
		an array containing the xbot IDs of the xbots specified in this command.
	targets_x_meters: List[float]
		An array containing the target x positions. (m)
	targets_y_meters: List[float]
		An array containing the target y positions. (m)
	final_speeds_meters_ps: List[float]
		An array containing the final speed (m/s)
	max_speeds_meters_ps: List[float]
		An array containing the max speed (m/s)
	max_acceleration_meters_ps2: List[float]
		An array containing the max acceleration (m/s^2)

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(xbot_count, int, "xbot_count")
	

	targets_x_meters = [float(x) for x in targets_x_meters]
	targets_y_meters = [float(x) for x in targets_y_meters]
	final_speeds_meters_ps = [float(x) for x in final_speeds_meters_ps]
	max_speeds_meters_ps = [float(x) for x in max_speeds_meters_ps]
	max_acceleration_meters_ps2 = [float(x) for x in max_acceleration_meters_ps2]

	rtn = __bot.SyncMotionSI(int(xbot_count),xbot_ids,targets_x_meters,targets_y_meters,final_speeds_meters_ps,max_speeds_meters_ps,max_acceleration_meters_ps2)

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"sync_motion_si command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		rtn.TravelTimeSecs



def async_motion_si(
	xbot_count: int,
	mode: pm.ASYNCOPTIONS,
	xbot_ids: List[int],
	targets_x_meters: List[float],
	targets_y_meters: List[float]
):
	"""deprecated, please use AutoDrivingMotionSI command, automatically route xbots to their target positions

	Parameters
	----------
	xbot_count: int
		number of xbots specified in this command, up to 10
	mode: pm.ASYNCOPTIONS
		 0 = all xbots are involved in the move
	xbot_ids: List[int]
		an array containing the xbot IDs of the xbots specified in this command.
	targets_x_meters: List[float]
		An array containing the target x positions. (m)
	targets_y_meters: List[float]
		An array containing the target y positions. (m)

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(xbot_count, int, "xbot_count")
	assert_type(mode, pm.ASYNCOPTIONS, "mode")
	
	mode_enum = PMCLIB.ASYNCOPTIONS(mode)

	targets_x_meters = [float(x) for x in targets_x_meters]
	targets_y_meters = [float(x) for x in targets_y_meters]

	rtn = __bot.AsyncMotionSI(int(xbot_count),mode_enum,xbot_ids,targets_x_meters,targets_y_meters)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"async_motion_si command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def auto_driving_motion_si(
	xbot_count: int,
	mode: pm.ASYNCOPTIONS,
	xbot_ids: List[int],
	targets_x_meters: List[float],
	targets_y_meters: List[float]
):
	"""auto driving motion command, automatically route xbots to their target positions

	Parameters
	----------
	xbot_count: int
		number of xbots specified in this command, up to 10
	mode: pm.ASYNCOPTIONS
		 0 = all xbots are involved in the move
	xbot_ids: List[int]
		an array containing the xbot IDs of the xbots specified in this command.
	targets_x_meters: List[float]
		An array containing the target x positions. (m)
	targets_y_meters: List[float]
		An array containing the target y positions. (m)

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(xbot_count, int, "xbot_count")
	assert_type(mode, pm.ASYNCOPTIONS, "mode")
	
	mode_enum = PMCLIB.ASYNCOPTIONS(mode)

	targets_x_meters = [float(x) for x in targets_x_meters]
	targets_y_meters = [float(x) for x in targets_y_meters]

	rtn = __bot.AutoDrivingMotionSI(int(xbot_count),mode_enum,xbot_ids,targets_x_meters,targets_y_meters)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"auto_driving_motion_si command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def auto_driving_motion_si_with_speed(
	xbot_count: int = None,
	mode: pm.ASYNCOPTIONS = None,
	max_speed: float = None,
	max_accel: float = None,
	xbot_ids: List[int] = None,
	targets_x_meters: List[float] = None,
	targets_y_meters: List[float] = None,
	zone_id: int = None
):
	"""auto driving motion command, automatically route xbots to their target positions, with speed and acceleration

	Parameters
	----------
		Option 1
		------------
		xbot_count: int
			number of xbots specified in this command, up to 10
		mode: pm.ASYNCOPTIONS
			 0 = all xbots are involved in the move
		max_speed: float
			max speed used during motion
		max_accel: float
			max acceleration used during motion
		xbot_ids: List[int]
			an array containing the xbot IDs of the xbots specified in this command.
		targets_x_meters: List[float]
			An array containing the target x positions. (m)
		targets_y_meters: List[float]
			An array containing the target y positions. (m)
		zone_id: int
			pre-defined fenced zone for movers to be routing in. All movers to be routed must already be inside the fenced zone. zone ID = 0 means no zone
		Option 2
		------------
		xbot_count: int
			number of xbots specified in this command, up to 10
		mode: pm.ASYNCOPTIONS
			 0 = all xbots are involved in the move
		max_speed: float
			max speed used during motion
		max_accel: float
			max acceleration used during motion
		xbot_ids: List[int]
			an array containing the xbot IDs of the xbots specified in this command.
		targets_x_meters: List[float]
			An array containing the target x positions. (m)
		targets_y_meters: List[float]
			An array containing the target y positions. (m)

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	
	provided_args = {key for key, value in locals().items() if value is not None}
	
	allowed_combination = [
		frozenset({'xbot_count','mode','max_speed','max_accel','xbot_ids','targets_x_meters','targets_y_meters','zone_id'}),
		frozenset({'xbot_count','mode','max_speed','max_accel','xbot_ids','targets_x_meters','targets_y_meters'})
	]

	if provided_args not in allowed_combination:
		raise ValueError("Invalid combinations of arguments")

	combination = 1
	for combos in allowed_combination:
		if provided_args != combos: combination += 1
		else:
			break
	
	if combination == 1:
		assert_type(xbot_count, int, "xbot_count")
		assert_type(mode, pm.ASYNCOPTIONS, "mode")
		assert_type(max_speed, float, "max_speed")
		assert_type(max_accel, float, "max_accel")
		assert_type(zone_id, int, "zone_id")
	
		mode_enum = PMCLIB.ASYNCOPTIONS(mode)

		targets_x_meters = [float(x) for x in targets_x_meters]
		targets_y_meters = [float(x) for x in targets_y_meters]

		rtn = __bot.AutoDrivingMotionSIWithSpeed(int(xbot_count),mode_enum,float(max_speed),float(max_accel),xbot_ids,targets_x_meters,targets_y_meters,int(zone_id))

	elif combination == 2:
		assert_type(xbot_count, int, "xbot_count")
		assert_type(mode, pm.ASYNCOPTIONS, "mode")
		assert_type(max_speed, float, "max_speed")
		assert_type(max_accel, float, "max_accel")
	
		mode_enum = PMCLIB.ASYNCOPTIONS(mode)

		targets_x_meters = [float(x) for x in targets_x_meters]
		targets_y_meters = [float(x) for x in targets_y_meters]

		rtn = __bot.AutoDrivingMotionSIWithSpeed(int(xbot_count),mode_enum,float(max_speed),float(max_accel),xbot_ids,targets_x_meters,targets_y_meters)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"auto_driving_motion_si_with_speed command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def edit_motion_macro(
	motion_macro_option: pm.MOTIONMACROOPTIONS,
	motion_macro_id: int
):
	"""motion macro control command

	Parameters
	----------
	motion_macro_option: pm.MOTIONMACROOPTIONS
		0 = clear macro; 1 = save macro; 2 = copy macro
	motion_macro_id: int
		macro ID

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(motion_macro_option, pm.MOTIONMACROOPTIONS, "motion_macro_option")
	assert_type(motion_macro_id, int, "motion_macro_id")
	
	motion_macro_option_enum = PMCLIB.MOTIONMACROOPTIONS(motion_macro_option)


	rtn = __bot.EditMotionMacro(motion_macro_option_enum,int(motion_macro_id))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"edit_motion_macro command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		pm.MotionMacroStatus(
		rtn.motionMacroStatus.macroID,
		rtn.motionMacroStatus.macroState,
		rtn.motionMacroStatus.storedCommandsCount

	)




def run_motion_macro(
	cmd_label: int,
	motion_macro_id: int,
	xbot_id: int
):
	"""copies the motion commands stored in the macro into the specified xbot

	Parameters
	----------
	cmd_label: int
		2 byte command label, converted to unsigned short
	motion_macro_id: int
		motion macro ID
	xbot_id: int
		target xbot ID

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(cmd_label, int, "cmd_label")
	assert_type(motion_macro_id, int, "motion_macro_id")
	assert_type(xbot_id, int, "xbot_id")
	


	rtn = __bot.RunMotionMacro(UInt16(cmd_label),int(motion_macro_id),int(xbot_id))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"run_motion_macro command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def write_xbot_payload_settings(
	xbot_id: int,
	payload: pm.XBotPayloadSettings
):
	"""Adjust parameters for an XBot carrying a load

	Parameters
	----------
	xbot_id: int
		ID of the XBot carrying load
	payload: pm.XBotPayloadSettings
		Details about the load carried by the XBot

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(xbot_id, int, "xbot_id")
	assert_type(payload, pm.XBotPayloadSettings, "payload")
	
	payload_enum = PMCLIB.XBotPayloadSettings()
	payload_enum.payloadkg = payload.payloadkg
	payload_enum.payloadCGHeightm = payload.payload_cg_heightm
	payload_enum.payloadDimensionXm = payload.payload_dimension_xm
	payload_enum.payloadDimensionYm = payload.payload_dimension_ym



	rtn = __bot.WriteXBotPayloadSettings(int(xbot_id),payload_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"write_xbot_payload_settings command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def write_xbot_payload_settings_multiple(
	xbot_count: int,
	xbot_ids: List[int],
	payload_settings: List[pm.XBotPayloadSettings]
):
	"""Adjust parameters for up to 3 XBots carrying loads

	Parameters
	----------
	xbot_count: int
		number of xbots to set in this command
	xbot_ids: List[int]
		the array of xbot IDs
	payload_settings: List[pm.XBotPayloadSettings]
		the array of payload settings that corresponds to the previously provided XBOT IDs

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(xbot_count, int, "xbot_count")
	
	payload_settings_enum = [PMCLIB.XBotPayloadSettings()]*len(payload_settings)

	for i, x in enumerate(payload_settings):
		payload_settings_enum[i].payloadkg = x.payloadkg
		payload_settings_enum[i].payloadCGHeightm = x.payload_cg_heightm
		payload_settings_enum[i].payloadDimensionXm = x.payload_dimension_xm
		payload_settings_enum[i].payloadDimensionYm = x.payload_dimension_ym


	rtn = __bot.WriteXBotPayloadSettingsMultiple(int(xbot_count),xbot_ids,payload_settings_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"write_xbot_payload_settings_multiple command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def read_xbot_payload_settings(
	xbot_id: int
):
	"""get the current payload settings of the xbot in question

	Parameters
	----------
	xbot_id: int
		xbot ID to check

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(xbot_id, int, "xbot_id")
	


	rtn = __bot.ReadXBotPayloadSettings(int(xbot_id))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"read_xbot_payload_settings command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		pm.XBotPayloadSettings(
		rtn.PayloadSettings.payloadkg,
		rtn.PayloadSettings.payloadCGHeightm,
		rtn.PayloadSettings.payloadDimensionXm,
		rtn.PayloadSettings.payloadDimensionYm

	)




def set_mover_properties(
	property_count: int,
	mover_properties: List[pm.MoverProperty]
):
	"""sets anywhere from 1 to 14 mover properties

	Parameters
	----------
	property_count: int
		number of properties this command is setting
	mover_properties: List[pm.MoverProperty]
		the property definition, including the mover ID, property ID, and property value

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(property_count, int, "property_count")
	
	mover_properties_enum = [PMCLIB.MoverProperty()]*len(mover_properties)

	for i, x in enumerate(mover_properties):
		mover_properties_enum[i].moverID = x.mover_id
		mover_properties_enum[i].propertyID = PMCLIB.MOVERPROPERTY(x.property_id)
		mover_properties_enum[i].propertyValue = x.property_value


	rtn = __bot.SetMoverProperties(int(property_count),mover_properties_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"set_mover_properties command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def get_mover_properties(
	mover_id: int,
	starting_property_id: int
):
	"""returns 8 consecutive mover properties for the specified mover, starting with the specified property ID

	Parameters
	----------
	mover_id: int
		the mover ID to get the properties for
	starting_property_id: int
		the property ID of the first property to get. Lowest number is 0

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(mover_id, int, "mover_id")
	assert_type(starting_property_id, int, "starting_property_id")
	


	rtn = __bot.GetMoverProperties(int(mover_id),int(starting_property_id))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_mover_properties command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return pm.MoverPropertyReturn(
		pm.PMCRTN(int(rtn.PmcRtn)),
		rtn.ValidPropertiesCount,
		[		pm.MoverProperty(
		x.moverID,
		pm.MOVERPROPERTY(int(x.propertyID)),
		x.propertyValue
		)
		for x in rtn.MoverProperties
	]
		)


def short_axes_motion_si(
	cmd_label: int = None,
	xbot_id: int = None,
	position_mode: pm.POSITIONMODE = None,
	target_zmeters: float = None,
	target_rx_rads: float = None,
	target_ry_rads: float = None,
	target_rz_rads: float = None,
	speed_zmeters_ps: float = None,
	speed_rx_rads_ps: float = None,
	speed_ry_rads_ps: float = None,
	speed_rz_rads_ps: float = None,
	center_mode: pm.SHORTAXESCENTERMODE = None,
	centerx_: float = None,
	centery_: float = None
):
	"""Short axes motion command

	Parameters
	----------
		Option 1
		------------
		cmd_label: int
			2 byte command label, converted to unsigned short
		xbot_id: int
			xbot ID
		position_mode: pm.POSITIONMODE
			0 = absolute position mode; 1 = relative position mode
		target_zmeters: float
			target z position, in meters
		target_rx_rads: float
			target rx position, in radians
		target_ry_rads: float
			target ry position, in radians
		target_rz_rads: float
			target rz position, in radians
		speed_zmeters_ps: float
			max z speed, in m/s
		speed_rx_rads_ps: float
			max rx speed, in rad/s
		speed_ry_rads_ps: float
			max ry speed, in rad/s
		speed_rz_rads_ps: float
			max rz speed, in rad/s
		Option 2
		------------
		cmd_label: int
			2 byte command label, converted to unsigned short
		xbot_id: int
			xbot ID
		position_mode: pm.POSITIONMODE
			0 = absolute position mode; 1 = relative position mode
		center_mode: pm.SHORTAXESCENTERMODE
			rotation center is: 0 = xbot center, 1 = user defined center
		centerx_: float
			user defined rotation center X
		centery_: float
			user defined rotation center Y
		target_zmeters: float
			target z position, in meters
		target_rx_rads: float
			target rx position, in radians
		target_ry_rads: float
			target ry position, in radians
		target_rz_rads: float
			target rz position, in radians
		speed_zmeters_ps: float
			max z speed, in m/s
		speed_rx_rads_ps: float
			max rx speed, in rad/s
		speed_ry_rads_ps: float
			max ry speed, in rad/s
		speed_rz_rads_ps: float
			max rz speed, in rad/s

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	
	provided_args = {key for key, value in locals().items() if value is not None}
	
	allowed_combination = [
		frozenset({'cmd_label','xbot_id','position_mode','target_zmeters','target_rx_rads','target_ry_rads','target_rz_rads','speed_zmeters_ps','speed_rx_rads_ps','speed_ry_rads_ps','speed_rz_rads_ps'}),
		frozenset({'cmd_label','xbot_id','position_mode','center_mode','centerx_','centery_','target_zmeters','target_rx_rads','target_ry_rads','target_rz_rads','speed_zmeters_ps','speed_rx_rads_ps','speed_ry_rads_ps','speed_rz_rads_ps'})
	]

	if provided_args not in allowed_combination:
		raise ValueError("Invalid combinations of arguments")

	combination = 1
	for combos in allowed_combination:
		if provided_args != combos: combination += 1
		else:
			break
	
	if combination == 1:
		assert_type(cmd_label, int, "cmd_label")
		assert_type(xbot_id, int, "xbot_id")
		assert_type(position_mode, pm.POSITIONMODE, "position_mode")
		assert_type(target_zmeters, float, "target_zmeters")
		assert_type(target_rx_rads, float, "target_rx_rads")
		assert_type(target_ry_rads, float, "target_ry_rads")
		assert_type(target_rz_rads, float, "target_rz_rads")
		assert_type(speed_zmeters_ps, float, "speed_zmeters_ps")
		assert_type(speed_rx_rads_ps, float, "speed_rx_rads_ps")
		assert_type(speed_ry_rads_ps, float, "speed_ry_rads_ps")
		assert_type(speed_rz_rads_ps, float, "speed_rz_rads_ps")
	
		position_mode_enum = PMCLIB.POSITIONMODE(position_mode)


		rtn = __bot.ShortAxesMotionSI(UInt16(cmd_label),int(xbot_id),position_mode_enum,float(target_zmeters),float(target_rx_rads),float(target_ry_rads),float(target_rz_rads),float(speed_zmeters_ps),float(speed_rx_rads_ps),float(speed_ry_rads_ps),float(speed_rz_rads_ps))

	elif combination == 2:
		assert_type(cmd_label, int, "cmd_label")
		assert_type(xbot_id, int, "xbot_id")
		assert_type(position_mode, pm.POSITIONMODE, "position_mode")
		assert_type(center_mode, pm.SHORTAXESCENTERMODE, "center_mode")
		assert_type(centerx_, float, "centerx_")
		assert_type(centery_, float, "centery_")
		assert_type(target_zmeters, float, "target_zmeters")
		assert_type(target_rx_rads, float, "target_rx_rads")
		assert_type(target_ry_rads, float, "target_ry_rads")
		assert_type(target_rz_rads, float, "target_rz_rads")
		assert_type(speed_zmeters_ps, float, "speed_zmeters_ps")
		assert_type(speed_rx_rads_ps, float, "speed_rx_rads_ps")
		assert_type(speed_ry_rads_ps, float, "speed_ry_rads_ps")
		assert_type(speed_rz_rads_ps, float, "speed_rz_rads_ps")
	
		position_mode_enum = PMCLIB.POSITIONMODE(position_mode)
		center_mode_enum = PMCLIB.SHORTAXESCENTERMODE(center_mode)


		rtn = __bot.ShortAxesMotionSI(UInt16(cmd_label),int(xbot_id),position_mode_enum,center_mode_enum,float(centerx_),float(centery_),float(target_zmeters),float(target_rx_rads),float(target_ry_rads),float(target_rz_rads),float(speed_zmeters_ps),float(speed_rx_rads_ps),float(speed_ry_rads_ps),float(speed_rz_rads_ps))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"short_axes_motion_si command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		rtn.TravelTimeSecs



def six_dof_motion_si(
	cmd_label: int = None,
	xbot_id: int = None,
	target_xmeters: float = None,
	target_ymeters: float = None,
	target_zmeters: float = None,
	target_rx_rads: float = None,
	target_ry_rads: float = None,
	target_rz_rads: float = None,
	xy_max_speed: float = None,
	xy_max_accel: float = None,
	z_max_speed: float = None,
	rx_max_speed: float = None,
	ry_max_speed: float = None,
	rz_max_speed: float = None
):
	"""6DOF motion command

	Parameters
	----------
		Option 1
		------------
		cmd_label: int
			2 byte command label, converted to unsigned short
		xbot_id: int
			xbot ID
		target_xmeters: float
			target x position, in meters
		target_ymeters: float
			target y position, in meters
		target_zmeters: float
			target z position, in meters
		target_rx_rads: float
			target rx position, in radians
		target_ry_rads: float
			target ry position, in radians
		target_rz_rads: float
			target rz position, in radians
		Option 2
		------------
		cmd_label: int
			2 byte command label, converted to unsigned short
		xbot_id: int
			xbot ID
		target_xmeters: float
			target x position, in meters
		target_ymeters: float
			target y position, in meters
		target_zmeters: float
			target z position, in meters
		target_rx_rads: float
			target rx position, in radians
		target_ry_rads: float
			target ry position, in radians
		target_rz_rads: float
			target rz position, in radians
		xy_max_speed: float
			maximum xy motion speed
		xy_max_accel: float
			maximum xy motion acceleration
		z_max_speed: float
			maximum z speed
		rx_max_speed: float
			maximum rx speed
		ry_max_speed: float
			maximum ry speed
		rz_max_speed: float
			maximum rz speed

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	
	provided_args = {key for key, value in locals().items() if value is not None}
	
	allowed_combination = [
		frozenset({'cmd_label','xbot_id','target_xmeters','target_ymeters','target_zmeters','target_rx_rads','target_ry_rads','target_rz_rads'}),
		frozenset({'cmd_label','xbot_id','target_xmeters','target_ymeters','target_zmeters','target_rx_rads','target_ry_rads','target_rz_rads','xy_max_speed','xy_max_accel','z_max_speed','rx_max_speed','ry_max_speed','rz_max_speed'})
	]

	if provided_args not in allowed_combination:
		raise ValueError("Invalid combinations of arguments")

	combination = 1
	for combos in allowed_combination:
		if provided_args != combos: combination += 1
		else:
			break
	
	if combination == 1:
		assert_type(cmd_label, int, "cmd_label")
		assert_type(xbot_id, int, "xbot_id")
		assert_type(target_xmeters, float, "target_xmeters")
		assert_type(target_ymeters, float, "target_ymeters")
		assert_type(target_zmeters, float, "target_zmeters")
		assert_type(target_rx_rads, float, "target_rx_rads")
		assert_type(target_ry_rads, float, "target_ry_rads")
		assert_type(target_rz_rads, float, "target_rz_rads")
	


		rtn = __bot.SixDofMotionSI(UInt16(cmd_label),int(xbot_id),float(target_xmeters),float(target_ymeters),float(target_zmeters),float(target_rx_rads),float(target_ry_rads),float(target_rz_rads))

	elif combination == 2:
		assert_type(cmd_label, int, "cmd_label")
		assert_type(xbot_id, int, "xbot_id")
		assert_type(target_xmeters, float, "target_xmeters")
		assert_type(target_ymeters, float, "target_ymeters")
		assert_type(target_zmeters, float, "target_zmeters")
		assert_type(target_rx_rads, float, "target_rx_rads")
		assert_type(target_ry_rads, float, "target_ry_rads")
		assert_type(target_rz_rads, float, "target_rz_rads")
		assert_type(xy_max_speed, float, "xy_max_speed")
		assert_type(xy_max_accel, float, "xy_max_accel")
		assert_type(z_max_speed, float, "z_max_speed")
		assert_type(rx_max_speed, float, "rx_max_speed")
		assert_type(ry_max_speed, float, "ry_max_speed")
		assert_type(rz_max_speed, float, "rz_max_speed")
	


		rtn = __bot.SixDofMotionSI(UInt16(cmd_label),int(xbot_id),float(target_xmeters),float(target_ymeters),float(target_zmeters),float(target_rx_rads),float(target_ry_rads),float(target_rz_rads),float(xy_max_speed),float(xy_max_accel),float(z_max_speed),float(rx_max_speed),float(ry_max_speed),float(rz_max_speed))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"six_dof_motion_si command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		rtn.TravelTimeSecs



def stop_motion(
	xbot_id: int
):
	"""stop xbot(s) motion

	Parameters
	----------
	xbot_id: int
		xbot ID, 0 = all Xbots

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(xbot_id, int, "xbot_id")
	


	rtn = __bot.StopMotion(int(xbot_id))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"stop_motion command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def motion_buffer_control(
	xbot_id: int,
	buffer_option: pm.MOTIONBUFFEROPTIONS
):
	"""motion buffer control

	Parameters
	----------
	xbot_id: int
		xbot ID
	buffer_option: pm.MOTIONBUFFEROPTIONS
		0 = block buffer; 1 = unblock buffer; 2 = clear buffer

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(xbot_id, int, "xbot_id")
	assert_type(buffer_option, pm.MOTIONBUFFEROPTIONS, "buffer_option")
	
	buffer_option_enum = PMCLIB.MOTIONBUFFEROPTIONS(buffer_option)


	rtn = __bot.MotionBufferControl(int(xbot_id),buffer_option_enum)

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"motion_buffer_control command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		pm.MotionBufferStatus(
		rtn.motionBufferStatus.isBufferBlocked,
		rtn.motionBufferStatus.bufferedMotionCount,
		rtn.motionBufferStatus.firstBufferedMotionCmdLabel,
		rtn.motionBufferStatus.lastBufferedMotionCmdLabel,
		rtn.motionBufferStatus.xbotID

	)




def group_control(
	group_option: pm.GROUPOPTIONS = None,
	group_id: int = None,
	xbot_count: int = None,
	xbot_ids: List[int] = None,
	bond_option: pm.GROUPBONDOPTIONS = None
):
	"""group control command

	Parameters
	----------
		Option 1
		------------
		group_option: pm.GROUPOPTIONS
			0 = create; 1 = delete; 2 = connect; 3 = disconnect; 4 = block; 5 = release; 6 = query status
		group_id: int
			group ID
		xbot_count: int
			number of XBots in the group, only useful for the create option. For other options, send 0
		xbot_ids: List[int]
			array of XBOT ids in the group, only useful for the create option. For other options, send null
		Option 2
		------------
		group_option: pm.GROUPOPTIONS
			0 = create; 1 = delete; 2 = connect; 3 = disconnect; 4 = block; 5 = release; 6 = query status
		group_id: int
			group ID
		bond_option: pm.GROUPBONDOPTIONS
			the bond option and axis coupling selection for the xbots
		xbot_count: int
			number of XBots in the group, only useful for the create option. For other options, send 0
		xbot_ids: List[int]
			array of XBOT ids in the group, only useful for the create option. For other options, send null

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	
	provided_args = {key for key, value in locals().items() if value is not None}
	
	allowed_combination = [
		frozenset({'group_option','group_id','xbot_count','xbot_ids'}),
		frozenset({'group_option','group_id','bond_option','xbot_count','xbot_ids'})
	]

	if provided_args not in allowed_combination:
		raise ValueError("Invalid combinations of arguments")

	combination = 1
	for combos in allowed_combination:
		if provided_args != combos: combination += 1
		else:
			break
	
	if combination == 1:
		assert_type(group_option, pm.GROUPOPTIONS, "group_option")
		assert_type(group_id, int, "group_id")
		assert_type(xbot_count, int, "xbot_count")
	
		group_option_enum = PMCLIB.GROUPOPTIONS(group_option)


		rtn = __bot.GroupControl(group_option_enum,int(group_id),int(xbot_count),xbot_ids)

	elif combination == 2:
		assert_type(group_option, pm.GROUPOPTIONS, "group_option")
		assert_type(group_id, int, "group_id")
		assert_type(bond_option, pm.GROUPBONDOPTIONS, "bond_option")
		assert_type(xbot_count, int, "xbot_count")
	
		group_option_enum = PMCLIB.GROUPOPTIONS(group_option)
		bond_option_enum = PMCLIB.GROUPBONDOPTIONS(bond_option)


		rtn = __bot.GroupControl(group_option_enum,int(group_id),bond_option_enum,int(xbot_count),xbot_ids)

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"group_control command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		pm.GroupInformation(
		rtn.groupInfo.groupID,
		rtn.groupInfo.groupStatus,
		rtn.groupInfo.groupMembersCount,
		[x for x in rtn.groupInfo.groupMembersIDs]

	)




def bond_xbot_group(
	group_id: int,
	is_bond: bool,
	bondoptions: pm.GROUPBONDOPTIONS
):
	"""Group bond command

	Parameters
	----------
	group_id: int
		group ID, 0 = bond all groups; >0 = bond specific group
	is_bond: bool
		true = bond group(s); false = unbound group(s)
	bondoptions: pm.GROUPBONDOPTIONS
		0 = decouple mode, 1 = couple mode

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(group_id, int, "group_id")
	assert_type(is_bond, bool, "is_bond")
	assert_type(bondoptions, pm.GROUPBONDOPTIONS, "bondoptions")
	
	bondoptions_enum = PMCLIB.GROUPBONDOPTIONS(bondoptions)


	rtn = __bot.BondXbotGroup(int(group_id),bool(is_bond),bondoptions_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"bond_xbot_group command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def get_group_status(
	group_id: int
):
	"""Queries the status of the specified group

	Parameters
	----------
	group_id: int
		group ID

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(group_id, int, "group_id")
	


	rtn = __bot.GetGroupStatus(int(group_id))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_group_status command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		pm.GroupInformation(
		rtn.groupInfo.groupID,
		rtn.groupInfo.groupStatus,
		rtn.groupInfo.groupMembersCount,
		[x for x in rtn.groupInfo.groupMembersIDs]

	)




def create_xbot_group(
	group_id: int,
	xbot_count: int,
	xbot_ids: List[int]
):
	"""Creates the specified xbot group

	Parameters
	----------
	group_id: int
		group ID (must be greater than 0)
	xbot_count: int
		number of xbots to be in the group
	xbot_ids: List[int]
		xbot ID#'s in to be added to the group

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(group_id, int, "group_id")
	assert_type(xbot_count, int, "xbot_count")
	


	rtn = __bot.CreateXbotGroup(int(group_id),int(xbot_count),xbot_ids)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"create_xbot_group command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def delete_xbot_group(
	group_id: int
):
	"""Deletes the specified xbot group

	Parameters
	----------
	group_id: int
		group ID

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(group_id, int, "group_id")
	


	rtn = __bot.DeleteXbotGroup(int(group_id))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"delete_xbot_group command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def block_xbot_group(
	group_id: int,
	is_block: bool
):
	"""Blocks/Releases the buffer for the specified group

	Parameters
	----------
	group_id: int
		group ID
	is_block: bool
		true = block buffer; false = release buffer

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(group_id, int, "group_id")
	assert_type(is_block, bool, "is_block")
	


	rtn = __bot.BlockXbotGroup(int(group_id),bool(is_block))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"block_xbot_group command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def get_xbot_status(
	xbot_id: int = None,
	feedback_type: pm.FEEDBACKOPTION = None
):
	"""get the full xbot status, including the xbot state amd position data

	Parameters
	----------
		Option 1
		------------
		xbot_id: int
			xbot id
		Option 2
		------------
		xbot_id: int
			xbot id
		feedback_type: pm.FEEDBACKOPTION
			choose whether the reply should contain position or force data

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	
	provided_args = {key for key, value in locals().items() if value is not None}
	
	allowed_combination = [
		frozenset({'xbot_id'}),
		frozenset({'xbot_id','feedback_type'})
	]

	if provided_args not in allowed_combination:
		raise ValueError("Invalid combinations of arguments")

	combination = 1
	for combos in allowed_combination:
		if provided_args != combos: combination += 1
		else:
			break
	
	if combination == 1:
		assert_type(xbot_id, int, "xbot_id")
	


		rtn = __bot.GetXbotStatus(int(xbot_id))

	elif combination == 2:
		assert_type(xbot_id, int, "xbot_id")
		assert_type(feedback_type, pm.FEEDBACKOPTION, "feedback_type")
	
		feedback_type_enum = PMCLIB.FEEDBACKOPTION(feedback_type)


		rtn = __bot.GetXbotStatus(int(xbot_id),feedback_type_enum)

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_xbot_status command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return pm.XBotStatus(
		pm.PMCRTN(int(rtn.PmcRtn)),
		pm.XBOTSTATE(int(rtn.XBOTState)),
		rtn.cmdLabel,
		rtn.inForceMode,
		[x for x in rtn.FeedbackPositionSI],
		rtn.isConnectedToGroup,
		rtn.connectedGroupID,
		rtn.isMotionBufferBlocked,
		rtn.bufferedMotionCount,
		rtn.stereotypeID,
		pm.MOVERTYPE(int(rtn.moverType))

		)


def get_all_xbot_info(
	feedback_option: pm.ALLXBOTSFEEDBACKOPTION
):
	"""Gets basic information about all XBots in the system in one command

	Parameters
	----------
	feedback_option: pm.ALLXBOTSFEEDBACKOPTION
		0 = provides position data in command reply, 1 = provides current reference data in command reply

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(feedback_option, pm.ALLXBOTSFEEDBACKOPTION, "feedback_option")
	
	feedback_option_enum = PMCLIB.ALLXBOTSFEEDBACKOPTION(feedback_option)


	rtn = __bot.GetAllXbotInfo(feedback_option_enum)

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_all_xbot_info command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		[		pm.XBotInfo(
		x.XPos,
		x.YPos,
		x.ZPos,
		x.RxPos,
		x.RyPos,
		x.RzPos,
		pm.XBOTSTATE(int(x.XBotState)),
		x.XbotID,
		pm.XBOTTYPE(int(x.XbotType))
		)
		for x in rtn.AllXbotInfoList
	]


def get_xbot_ids():
	"""Returns the XBOT IDs of the XBots detected by the system

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	

	rtn = __bot.GetXBotIDS()

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_xbot_ids command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return pm.XBotIDs(
		pm.PMCRTN(int(rtn.PmcRtn)),
		rtn.XBotCount,
		[x for x in rtn.XBotIDsArray]

		)


def trajectory_activation(
	cmd_label: int,
	xbot_count: int,
	xbot_ids: List[int],
	trajectory_ids: List[int]
):
	"""Activate trajectory for xbot(s)

	Parameters
	----------
	cmd_label: int
		2 byte command label, converted to unsigned short
	xbot_count: int
		number of xbots to activate trajectories for
	xbot_ids: List[int]
		an array containing the xbot IDs
	trajectory_ids: List[int]
		an array containing the corresponding trajectory IDs

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(cmd_label, int, "cmd_label")
	assert_type(xbot_count, int, "xbot_count")
	


	rtn = __bot.TrajectoryActivation(UInt16(cmd_label),int(xbot_count),xbot_ids,trajectory_ids)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"trajectory_activation command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def wait_until(
	cmd_label: int = None,
	xbot_id: int = None,
	start_option: pm.WAITUNTILSTARTOPTION = None,
	starting_trigger_source: pm.TRIGGERSOURCE = None,
	finishing_trigger_source: pm.TRIGGERSOURCE = None,
	starting_parameters: pm.WaitUntilTriggerParams = None,
	finish_trigger_count: pm.WaitUntilTriggerParams = None,
	finishing_parameters: int = None,
	trigger_source: pm.TRIGGERSOURCE = None,
	trigger_parameters: pm.WaitUntilTriggerParams = None,
	trigger_count: int = None
):
	"""Let's an XBOT wait until certain conditions are met before executing the next command

	Parameters
	----------
		Option 1
		------------
		cmd_label: int
			2 byte command label, converted to unsigned short
		xbot_id: int
			XBOT ID of the XBOT to wait
		start_option: pm.WAITUNTILSTARTOPTION
			if the command should start immediately, or start it at the option specified by the user
		starting_trigger_source: pm.TRIGGERSOURCE
			source of the trigger that will start the wait until monitoring.
		finishing_trigger_source: pm.TRIGGERSOURCE
			source of the trigger that will release the XBOT from waiting
		starting_parameters: pm.WaitUntilTriggerParams
			parameters for starting the Wait Until command, an empty input here means the Wait Until command should start monitoring after it is executing
		finish_trigger_count: pm.WaitUntilTriggerParams
			number of times for the finishing trigger condition to be met, before the wait is released
		finishing_parameters: int
			parameters for finishing the Wait Until command
		Option 2
		------------
		cmd_label: int
			2 byte command label, converted to unsigned short
		xbot_id: int
			XBOT ID of the XBOT to wait
		trigger_source: pm.TRIGGERSOURCE
			source of the trigger that will release the XBOT from waiting
		trigger_parameters: pm.WaitUntilTriggerParams
			parameters for activating the trigger source
		Option 3
		------------
		cmd_label: int
			2 byte command label, converted to unsigned short
		xbot_id: int
			XBOT ID of the XBOT to wait
		trigger_source: pm.TRIGGERSOURCE
			source of the trigger that will release the XBOT from waiting
		trigger_parameters: pm.WaitUntilTriggerParams
			parameters for activating the trigger source
		start_option: pm.WAITUNTILSTARTOPTION
			option for start monitoring
		trigger_count: int
			number of times for the trigger to occur before WaitUntil is released

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	
	provided_args = {key for key, value in locals().items() if value is not None}
	
	allowed_combination = [
		frozenset({'cmd_label','xbot_id','start_option','starting_trigger_source','finishing_trigger_source','starting_parameters','finish_trigger_count','finishing_parameters'}),
		frozenset({'cmd_label','xbot_id','trigger_source','trigger_parameters'}),
		frozenset({'cmd_label','xbot_id','trigger_source','trigger_parameters','start_option','trigger_count'})
	]

	if provided_args not in allowed_combination:
		raise ValueError("Invalid combinations of arguments")

	combination = 1
	for combos in allowed_combination:
		if provided_args != combos: combination += 1
		else:
			break
	
	if combination == 1:
		assert_type(cmd_label, int, "cmd_label")
		assert_type(xbot_id, int, "xbot_id")
		assert_type(start_option, pm.WAITUNTILSTARTOPTION, "start_option")
		assert_type(starting_trigger_source, pm.TRIGGERSOURCE, "starting_trigger_source")
		assert_type(finishing_trigger_source, pm.TRIGGERSOURCE, "finishing_trigger_source")
		assert_type(starting_parameters, pm.WaitUntilTriggerParams, "starting_parameters")
		assert_type(finish_trigger_count, pm.WaitUntilTriggerParams, "finish_trigger_count")
		assert_type(finishing_parameters, int, "finishing_parameters")
	
		start_option_enum = PMCLIB.WAITUNTILSTARTOPTION(start_option)
		starting_trigger_source_enum = PMCLIB.TRIGGERSOURCE(starting_trigger_source)
		finishing_trigger_source_enum = PMCLIB.TRIGGERSOURCE(finishing_trigger_source)
		starting_parameters_enum = PMCLIB.WaitUntilTriggerParams()
		starting_parameters_enum.delaySecs = starting_parameters.delay_secs
		starting_parameters_enum.externalOrFBInputChannelID = starting_parameters.external_or_fb_input_channel_id
		starting_parameters_enum.edgeType = PMCLIB.TRIGGEREDGETYPE(starting_parameters.edge_type)
		starting_parameters_enum.triggerXbotID = starting_parameters.triggerxbot_id
		starting_parameters_enum.triggerCmdLabel = starting_parameters.trigger_cmd_label
		starting_parameters_enum.triggerCmdType = PMCLIB.TRIGGERCMDTYPE(starting_parameters.trigger_cmd_type)
		starting_parameters_enum.CmdLabelTriggerType = PMCLIB.TRIGGERCMDLABELTYPE(starting_parameters.cmd_label_trigger_type)
		starting_parameters_enum.displacementTriggerType = PMCLIB.TRIGGERDISPLACEMENTTYPE(starting_parameters.displacement_trigger_type)
		starting_parameters_enum.displacementTriggerMode = PMCLIB.TRIGGERDISPLACEMENTMODE(starting_parameters.displacement_trigger_mode)
		starting_parameters_enum.lineParamAx = starting_parameters.line_param_ax
		starting_parameters_enum.lineParamBy = starting_parameters.line_param_by
		starting_parameters_enum.displacementThresholdMeters = starting_parameters.displacement_threshold_meters

		finish_trigger_count_enum = PMCLIB.WaitUntilTriggerParams()
		finish_trigger_count_enum.delaySecs = finish_trigger_count.delay_secs
		finish_trigger_count_enum.externalOrFBInputChannelID = finish_trigger_count.external_or_fb_input_channel_id
		finish_trigger_count_enum.edgeType = PMCLIB.TRIGGEREDGETYPE(finish_trigger_count.edge_type)
		finish_trigger_count_enum.triggerXbotID = finish_trigger_count.triggerxbot_id
		finish_trigger_count_enum.triggerCmdLabel = finish_trigger_count.trigger_cmd_label
		finish_trigger_count_enum.triggerCmdType = PMCLIB.TRIGGERCMDTYPE(finish_trigger_count.trigger_cmd_type)
		finish_trigger_count_enum.CmdLabelTriggerType = PMCLIB.TRIGGERCMDLABELTYPE(finish_trigger_count.cmd_label_trigger_type)
		finish_trigger_count_enum.displacementTriggerType = PMCLIB.TRIGGERDISPLACEMENTTYPE(finish_trigger_count.displacement_trigger_type)
		finish_trigger_count_enum.displacementTriggerMode = PMCLIB.TRIGGERDISPLACEMENTMODE(finish_trigger_count.displacement_trigger_mode)
		finish_trigger_count_enum.lineParamAx = finish_trigger_count.line_param_ax
		finish_trigger_count_enum.lineParamBy = finish_trigger_count.line_param_by
		finish_trigger_count_enum.displacementThresholdMeters = finish_trigger_count.displacement_threshold_meters



		rtn = __bot.WaitUntil(UInt16(cmd_label),int(xbot_id),start_option_enum,starting_trigger_source_enum,finishing_trigger_source_enum,starting_parameters_enum,finish_trigger_count_enum,int(finishing_parameters))

	elif combination == 2:
		assert_type(cmd_label, int, "cmd_label")
		assert_type(xbot_id, int, "xbot_id")
		assert_type(trigger_source, pm.TRIGGERSOURCE, "trigger_source")
		assert_type(trigger_parameters, pm.WaitUntilTriggerParams, "trigger_parameters")
	
		trigger_source_enum = PMCLIB.TRIGGERSOURCE(trigger_source)
		trigger_parameters_enum = PMCLIB.WaitUntilTriggerParams()
		trigger_parameters_enum.delaySecs = trigger_parameters.delay_secs
		trigger_parameters_enum.externalOrFBInputChannelID = trigger_parameters.external_or_fb_input_channel_id
		trigger_parameters_enum.edgeType = PMCLIB.TRIGGEREDGETYPE(trigger_parameters.edge_type)
		trigger_parameters_enum.triggerXbotID = trigger_parameters.triggerxbot_id
		trigger_parameters_enum.triggerCmdLabel = trigger_parameters.trigger_cmd_label
		trigger_parameters_enum.triggerCmdType = PMCLIB.TRIGGERCMDTYPE(trigger_parameters.trigger_cmd_type)
		trigger_parameters_enum.CmdLabelTriggerType = PMCLIB.TRIGGERCMDLABELTYPE(trigger_parameters.cmd_label_trigger_type)
		trigger_parameters_enum.displacementTriggerType = PMCLIB.TRIGGERDISPLACEMENTTYPE(trigger_parameters.displacement_trigger_type)
		trigger_parameters_enum.displacementTriggerMode = PMCLIB.TRIGGERDISPLACEMENTMODE(trigger_parameters.displacement_trigger_mode)
		trigger_parameters_enum.lineParamAx = trigger_parameters.line_param_ax
		trigger_parameters_enum.lineParamBy = trigger_parameters.line_param_by
		trigger_parameters_enum.displacementThresholdMeters = trigger_parameters.displacement_threshold_meters



		rtn = __bot.WaitUntil(UInt16(cmd_label),int(xbot_id),trigger_source_enum,trigger_parameters_enum)

	elif combination == 3:
		assert_type(cmd_label, int, "cmd_label")
		assert_type(xbot_id, int, "xbot_id")
		assert_type(trigger_source, pm.TRIGGERSOURCE, "trigger_source")
		assert_type(trigger_parameters, pm.WaitUntilTriggerParams, "trigger_parameters")
		assert_type(start_option, pm.WAITUNTILSTARTOPTION, "start_option")
		assert_type(trigger_count, int, "trigger_count")
	
		trigger_source_enum = PMCLIB.TRIGGERSOURCE(trigger_source)
		trigger_parameters_enum = PMCLIB.WaitUntilTriggerParams()
		trigger_parameters_enum.delaySecs = trigger_parameters.delay_secs
		trigger_parameters_enum.externalOrFBInputChannelID = trigger_parameters.external_or_fb_input_channel_id
		trigger_parameters_enum.edgeType = PMCLIB.TRIGGEREDGETYPE(trigger_parameters.edge_type)
		trigger_parameters_enum.triggerXbotID = trigger_parameters.triggerxbot_id
		trigger_parameters_enum.triggerCmdLabel = trigger_parameters.trigger_cmd_label
		trigger_parameters_enum.triggerCmdType = PMCLIB.TRIGGERCMDTYPE(trigger_parameters.trigger_cmd_type)
		trigger_parameters_enum.CmdLabelTriggerType = PMCLIB.TRIGGERCMDLABELTYPE(trigger_parameters.cmd_label_trigger_type)
		trigger_parameters_enum.displacementTriggerType = PMCLIB.TRIGGERDISPLACEMENTTYPE(trigger_parameters.displacement_trigger_type)
		trigger_parameters_enum.displacementTriggerMode = PMCLIB.TRIGGERDISPLACEMENTMODE(trigger_parameters.displacement_trigger_mode)
		trigger_parameters_enum.lineParamAx = trigger_parameters.line_param_ax
		trigger_parameters_enum.lineParamBy = trigger_parameters.line_param_by
		trigger_parameters_enum.displacementThresholdMeters = trigger_parameters.displacement_threshold_meters

		start_option_enum = PMCLIB.WAITUNTILSTARTOPTION(start_option)


		rtn = __bot.WaitUntil(UInt16(cmd_label),int(xbot_id),trigger_source_enum,trigger_parameters_enum,start_option_enum,int(trigger_count))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"wait_until command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def edit_planet_xbots(
	sun_xbot_id: int,
	planet_xbot_count: int,
	planet_xbot_ids: List[int],
	action: pm.PLANETOPTIONS
):
	"""Use this command to edit the planet XBOTs list of a sun XBOT

	Parameters
	----------
	sun_xbot_id: int
		Sun XBOT ID
	planet_xbot_count: int
		number of planet XBOTs
	planet_xbot_ids: List[int]
		array of planet XBOT IDs
	action: pm.PLANETOPTIONS
		whether to add the planets or remove the planets

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(sun_xbot_id, int, "sun_xbot_id")
	assert_type(planet_xbot_count, int, "planet_xbot_count")
	assert_type(action, pm.PLANETOPTIONS, "action")
	
	action_enum = PMCLIB.PLANETOPTIONS(action)


	rtn = __bot.EditPlanetXbots(int(sun_xbot_id),int(planet_xbot_count),planet_xbot_ids,action_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"edit_planet_xbots command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def payload_weighing_kg(
	xbot_id: int = None,
	duration_secs: float = None
):
	"""Provides the weight of the payload, as measured by the specified XBOT

	Parameters
	----------
		Option 1
		------------
		xbot_id: int
			ID of the XBOT carrying the payload
		Option 2
		------------
		xbot_id: int
			ID of the XBOT carrying the payload
		duration_secs: float
			 duration for the XBot to wait while weighing 

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	
	provided_args = {key for key, value in locals().items() if value is not None}
	
	allowed_combination = [
		frozenset({'xbot_id'}),
		frozenset({'xbot_id','duration_secs'})
	]

	if provided_args not in allowed_combination:
		raise ValueError("Invalid combinations of arguments")

	combination = 1
	for combos in allowed_combination:
		if provided_args != combos: combination += 1
		else:
			break
	
	if combination == 1:
		assert_type(xbot_id, int, "xbot_id")
	


		rtn = __bot.PayloadWeighingKg(int(xbot_id))

	elif combination == 2:
		assert_type(xbot_id, int, "xbot_id")
		assert_type(duration_secs, float, "duration_secs")
	


		rtn = __bot.PayloadWeighingKg(int(xbot_id),float(duration_secs))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"payload_weighing_kg command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		rtn.WeightKG



def tare_mover(
	xbot_id: int
):
	"""Tare Xbot weighing

	Parameters
	----------
	xbot_id: int
		xbot ID (>0)

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(xbot_id, int, "xbot_id")
	


	rtn = __bot.TareMover(int(xbot_id))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"tare_mover command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def motion_interrupt_command(
	xbot_id: int,
	motion_interrupt_option: pm.MOTIONINTERRUPTOPTIONS
):
	"""Pause or resume the motion of an Xbot

	Parameters
	----------
	xbot_id: int
		XBOT ID
	motion_interrupt_option: pm.MOTIONINTERRUPTOPTIONS
		0 = Resume, 1 = Pause

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(xbot_id, int, "xbot_id")
	assert_type(motion_interrupt_option, pm.MOTIONINTERRUPTOPTIONS, "motion_interrupt_option")
	
	motion_interrupt_option_enum = PMCLIB.MOTIONINTERRUPTOPTIONS(motion_interrupt_option)


	rtn = __bot.MotionInterruptCommand(int(xbot_id),motion_interrupt_option_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"motion_interrupt_command command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def cam_control_command(
	cmd_label: int,
	cam_cmd_action: pm.CAMOPTIONS,
	slave_xbot_id: int,
	axis_count: int,
	cam_axis_data: List[pm.CamAxisDataClass]
):
	"""use this command to start or stop cam operations

	Parameters
	----------
	cmd_label: int
		command label
	cam_cmd_action: pm.CAMOPTIONS
		start or stop cam operation
	slave_xbot_id: int
		XBOT ID of the slave XBOT (it will follow other xbots' motions)
	axis_count: int
		how many axis of the slave XBOT will be configured by this command
	cam_axis_data: List[pm.CamAxisDataClass]
		detailed axis pairing data

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(cmd_label, int, "cmd_label")
	assert_type(cam_cmd_action, pm.CAMOPTIONS, "cam_cmd_action")
	assert_type(slave_xbot_id, int, "slave_xbot_id")
	assert_type(axis_count, int, "axis_count")
	
	cam_cmd_action_enum = PMCLIB.CAMOPTIONS(cam_cmd_action)
	cam_axis_data_enum = [PMCLIB.CamAxisDataClass()]*len(cam_axis_data)

	for i, x in enumerate(cam_axis_data):
		cam_axis_data_enum[i].MasterXID = x.masterx_id
		cam_axis_data_enum[i].MasterAxisID = PMCLIB.AXISNAMES(x.master_axis_id)
		cam_axis_data_enum[i].SlaveAxisID = PMCLIB.AXISNAMES(x.slave_axis_id)
		cam_axis_data_enum[i].CamID = x.cam_id


	rtn = __bot.CamControlCommand(UInt16(cmd_label),cam_cmd_action_enum,int(slave_xbot_id),int(axis_count),cam_axis_data_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"cam_control_command command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def cam_control_advanced_command(
	cmd_label: int,
	cam_cmd_action: pm.CAMOPTIONS,
	slave_xbot_id: int,
	axis_count: int,
	cam_axis_data: List[pm.CamAxisDataClassExtended]
):
	"""use this command to start or stop cam operations, advanced parameters available

	Parameters
	----------
	cmd_label: int
		command label
	cam_cmd_action: pm.CAMOPTIONS
		start or stop cam operation
	slave_xbot_id: int
		XBOT ID of the slave XBOT (it will follow other xbots' motions)
	axis_count: int
		how many axis of the slave XBOT will be configured by this command
	cam_axis_data: List[pm.CamAxisDataClassExtended]
		detailed axis pairing data

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(cmd_label, int, "cmd_label")
	assert_type(cam_cmd_action, pm.CAMOPTIONS, "cam_cmd_action")
	assert_type(slave_xbot_id, int, "slave_xbot_id")
	assert_type(axis_count, int, "axis_count")
	
	cam_cmd_action_enum = PMCLIB.CAMOPTIONS(cam_cmd_action)
	cam_axis_data_enum = [PMCLIB.CamAxisDataClassExtended()]*len(cam_axis_data)

	for i, x in enumerate(cam_axis_data):
		cam_axis_data_enum[i].MasterXID = x.masterx_id
		cam_axis_data_enum[i].MasterAxisID = PMCLIB.AXISNAMES(x.master_axis_id)
		cam_axis_data_enum[i].SlaveAxisID = PMCLIB.AXISNAMES(x.slave_axis_id)
		cam_axis_data_enum[i].CamID = x.cam_id
		cam_axis_data_enum[i].CamMode = PMCLIB.CAMMODE(x.cam_mode)
		cam_axis_data_enum[i].MasterAxisScaling = x.master_axis_scaling
		cam_axis_data_enum[i].SlaveAxisScaling = x.slave_axis_scaling
		cam_axis_data_enum[i].MasterAxisOffsetM = x.master_axis_offset_m
		cam_axis_data_enum[i].MasterAxisOffsetMode = PMCLIB.POSITIONMODE(x.master_axis_offset_mode)
		cam_axis_data_enum[i].SlaveAxisOffsetM = x.slave_axis_offset_m
		cam_axis_data_enum[i].SlaveAxisOffsetMode = PMCLIB.POSITIONMODE(x.slave_axis_offset_mode)
		cam_axis_data_enum[i].MasterAxisRatchetDirection = PMCLIB.CAMRATCHETDIRECTION(x.master_axis_ratchet_direction)


	rtn = __bot.CamControlAdvancedCommand(UInt16(cmd_label),cam_cmd_action_enum,int(slave_xbot_id),int(axis_count),cam_axis_data_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"cam_control_advanced_command command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def set_xbot_force_mode(
	xbot_id: int = None,
	force_option: pm.FORCEMODEOPTION = None,
	force_input: pm.XBotForceSetting = None,
	force_mode_type: pm.FORCEMODETYPE = None,
	buffer_command: bool = None,
	force_mode_axes: pm.ForceModeAxes = None
):
	"""Apply open-loop force in user specified direction(s) for a particular XBot

	Parameters
	----------
		Option 1
		------------
		xbot_id: int
			 XBot to apply force mode 
		force_option: pm.FORCEMODEOPTION
			 Enum to select which axis to apply force mode 
		force_input: pm.XBotForceSetting
			 Force input struct specifying the desired open-loop force/torque magnitudes 
		force_mode_type: pm.FORCEMODETYPE
			Force Mode Type (Absolute or Relative)
		buffer_command: bool
			If "true", buffers the ForceMode command at the end of the current buffered commands, otherwise, the command executes immediately
		Option 2
		------------
		xbot_id: int
			XBot to apply force mode
		force_mode_axes: pm.ForceModeAxes
			Struct of bools to select which axis to apply force mode, if true turns on Force Mode for that axis
		force_input: pm.XBotForceSetting
			Force input struct specifying the desired open-loop force/torque magnitudes
		force_mode_type: pm.FORCEMODETYPE
			Force Mode Type (Absolute or Relative)
		buffer_command: bool
			If "true", buffers the ForceMode command at the end of the current buffered commands, otherwise, the command executes immediately

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	
	provided_args = {key for key, value in locals().items() if value is not None}
	
	allowed_combination = [
		frozenset({'xbot_id','force_option','force_input','force_mode_type','buffer_command'}),
		frozenset({'xbot_id','force_mode_axes','force_input','force_mode_type','buffer_command'})
	]

	if provided_args not in allowed_combination:
		raise ValueError("Invalid combinations of arguments")

	combination = 1
	for combos in allowed_combination:
		if provided_args != combos: combination += 1
		else:
			break
	
	if combination == 1:
		assert_type(xbot_id, int, "xbot_id")
		assert_type(force_option, pm.FORCEMODEOPTION, "force_option")
		assert_type(force_input, pm.XBotForceSetting, "force_input")
		assert_type(force_mode_type, pm.FORCEMODETYPE, "force_mode_type")
		assert_type(buffer_command, bool, "buffer_command")
	
		force_option_enum = PMCLIB.FORCEMODEOPTION(force_option)
		force_input_enum = PMCLIB.XBotForceSetting()
		force_input_enum.Fx = force_input.fx
		force_input_enum.Fy = force_input.fy
		force_input_enum.Fz = force_input.fz
		force_input_enum.Tx = force_input.tx
		force_input_enum.Ty = force_input.ty
		force_input_enum.Tz = force_input.tz

		force_mode_type_enum = PMCLIB.FORCEMODETYPE(force_mode_type)


		rtn = __bot.SetXBotForceMode(int(xbot_id),force_option_enum,force_input_enum,force_mode_type_enum,bool(buffer_command))

	elif combination == 2:
		assert_type(xbot_id, int, "xbot_id")
		assert_type(force_mode_axes, pm.ForceModeAxes, "force_mode_axes")
		assert_type(force_input, pm.XBotForceSetting, "force_input")
		assert_type(force_mode_type, pm.FORCEMODETYPE, "force_mode_type")
		assert_type(buffer_command, bool, "buffer_command")
	
		force_mode_axes_enum = PMCLIB.ForceModeAxes()
		force_mode_axes_enum.X = force_mode_axes.x
		force_mode_axes_enum.Y = force_mode_axes.y
		force_mode_axes_enum.Z = force_mode_axes.z
		force_mode_axes_enum.Rx = force_mode_axes.rx
		force_mode_axes_enum.Ry = force_mode_axes.ry
		force_mode_axes_enum.Rz = force_mode_axes.rz

		force_input_enum = PMCLIB.XBotForceSetting()
		force_input_enum.Fx = force_input.fx
		force_input_enum.Fy = force_input.fy
		force_input_enum.Fz = force_input.fz
		force_input_enum.Tx = force_input.tx
		force_input_enum.Ty = force_input.ty
		force_input_enum.Tz = force_input.tz

		force_mode_type_enum = PMCLIB.FORCEMODETYPE(force_mode_type)


		rtn = __bot.SetXBotForceMode(int(xbot_id),force_mode_axes_enum,force_input_enum,force_mode_type_enum,bool(buffer_command))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"set_xbot_force_mode command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def release_xbot_force_mode(
	xbot_id: int
):
	"""Release XBot from open-loop force mode

	Parameters
	----------
	xbot_id: int
		 The ID of the XBot to release from force mode 

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(xbot_id, int, "xbot_id")
	


	rtn = __bot.ReleaseXBotForceMode(int(xbot_id))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"release_xbot_force_mode command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def define_mover_stereotype(
	mover_type: pm.MOVERTYPE,
	stereotype_id: int,
	stereotype_data: pm.MoverStereotypeData
):
	"""defines a mover stereotype, which can be applied to movers afterwards

	Parameters
	----------
	mover_type: pm.MOVERTYPE
		mover type
	stereotype_id: int
		stereotype id
	stereotype_data: pm.MoverStereotypeData
		stereotype data

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(mover_type, pm.MOVERTYPE, "mover_type")
	assert_type(stereotype_id, int, "stereotype_id")
	assert_type(stereotype_data, pm.MoverStereotypeData, "stereotype_data")
	
	mover_type_enum = PMCLIB.MOVERTYPE(mover_type)
	stereotype_data_enum = PMCLIB.MoverStereotypeData()
	stereotype_data_enum.performanceLevel = stereotype_data.performance_level
	stereotype_data_enum.payloadkg = stereotype_data.payloadkg
	stereotype_data_enum.payloadPositiveXmFromXBOTCenter = stereotype_data.payload_positive_xm_from_xbot_center
	stereotype_data_enum.payloadNegativeXmFromXBOTCenter = stereotype_data.payload_negative_xm_from_xbot_center
	stereotype_data_enum.payloadPositiveYmFromXBOTCenter = stereotype_data.payload_positive_ym_from_xbot_center
	stereotype_data_enum.payloadNegativeYmFromXBOTCenter = stereotype_data.payload_negative_ym_from_xbot_center
	stereotype_data_enum.payloadCGXm = stereotype_data.payload_cg_xm
	stereotype_data_enum.payloadCGYm = stereotype_data.payload_cg_ym
	stereotype_data_enum.payloadCGZm = stereotype_data.payload_cg_zm
	stereotype_data_enum.emergencyDeceleration = stereotype_data.emergency_deceleration



	rtn = __bot.DefineMoverStereotype(mover_type_enum,int(stereotype_id),stereotype_data_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"define_mover_stereotype command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def read_mover_stereotype_definition(
	mover_type: pm.MOVERTYPE,
	stereotype_id: int
):
	"""provides the full details of a mover stereotype definition

	Parameters
	----------
	mover_type: pm.MOVERTYPE
		mover type
	stereotype_id: int
		stereotype id

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(mover_type, pm.MOVERTYPE, "mover_type")
	assert_type(stereotype_id, int, "stereotype_id")
	
	mover_type_enum = PMCLIB.MOVERTYPE(mover_type)


	rtn = __bot.ReadMoverStereotypeDefinition(mover_type_enum,int(stereotype_id))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"read_mover_stereotype_definition command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		pm.MoverStereotypeData(
		rtn.StereotypeData.performanceLevel,
		rtn.StereotypeData.payloadkg,
		rtn.StereotypeData.payloadPositiveXmFromXBOTCenter,
		rtn.StereotypeData.payloadNegativeXmFromXBOTCenter,
		rtn.StereotypeData.payloadPositiveYmFromXBOTCenter,
		rtn.StereotypeData.payloadNegativeYmFromXBOTCenter,
		rtn.StereotypeData.payloadCGXm,
		rtn.StereotypeData.payloadCGYm,
		rtn.StereotypeData.payloadCGZm,
		rtn.StereotypeData.emergencyDeceleration

	)




def assign_stereotype_to_mover(
	mover_id: int,
	stereotype_id: int,
	option: pm.ASSIGNSTEREOTYPEOPTION
):
	"""assign a mover stereotype definition to a mover

	Parameters
	----------
	mover_id: int
		mover id
	stereotype_id: int
		stereotype id
	option: pm.ASSIGNSTEREOTYPEOPTION
		Option to specify either send the AssignStereotype command to buffer or run immediately

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(mover_id, int, "mover_id")
	assert_type(stereotype_id, int, "stereotype_id")
	assert_type(option, pm.ASSIGNSTEREOTYPEOPTION, "option")
	
	option_enum = PMCLIB.ASSIGNSTEREOTYPEOPTION(option)


	rtn = __bot.AssignStereotypeToMover(int(mover_id),int(stereotype_id),option_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"assign_stereotype_to_mover command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def auto_loading_zone_control(
	zone_op: pm.ALZONEOPERATION,
	zone_id: int,
	zone_definition: pm.AutoLoadZoneDefinition
):
	"""define or delete an auto load zone used to load or unload XBots from external devices onto the Flyway

	Parameters
	----------
	zone_op: pm.ALZONEOPERATION
		unload xbot from flyway, or load xbot onto flyway
	zone_id: int
		zone id
	zone_definition: pm.AutoLoadZoneDefinition
		parameters used to define the auto load zone area

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(zone_op, pm.ALZONEOPERATION, "zone_op")
	assert_type(zone_id, int, "zone_id")
	assert_type(zone_definition, pm.AutoLoadZoneDefinition, "zone_definition")
	
	zone_op_enum = PMCLIB.ALZONEOPERATION(zone_op)
	zone_definition_enum = PMCLIB.AutoLoadZoneDefinition()
	zone_definition_enum.BoundaryCenterXm = zone_definition.boundary_centerx_m
	zone_definition_enum.BoundaryCenterYm = zone_definition.boundary_centery_m
	zone_definition_enum.ZoneLengthm = zone_definition.zone_lengthm
	zone_definition_enum.ZoneWidthm = zone_definition.zone_widthm
	zone_definition_enum.ZoneType = PMCLIB.ALZONETYPE(zone_definition.zone_type)
	zone_definition_enum.UnloadingMode = PMCLIB.ALZONEUNLOADMODE(zone_definition.unloading_mode)
	zone_definition_enum.MaxXbotXSizem = zone_definition.max_xbot_x_sizem
	zone_definition_enum.MaxXbotYSizem = zone_definition.max_xbot_y_sizem
	zone_definition_enum.MaxSpeed = zone_definition.max_speed
	zone_definition_enum.MaxAccel = zone_definition.max_accel
	zone_definition_enum.MaxHeightm = zone_definition.max_heightm



	rtn = __bot.AutoLoadingZoneControl(zone_op_enum,int(zone_id),zone_definition_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"auto_loading_zone_control command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def auto_unload_xbot(
	xbot_id: int,
	auto_unload_zone_id: int
):
	"""automatically unload an XBot from the flyway using a previously defined auto unloading zone

	Parameters
	----------
	xbot_id: int
		xbot id
	auto_unload_zone_id: int
		zone ID of zone used to unload XBot

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(xbot_id, int, "xbot_id")
	assert_type(auto_unload_zone_id, int, "auto_unload_zone_id")
	


	rtn = __bot.AutoUnloadXBot(int(xbot_id),int(auto_unload_zone_id))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"auto_unload_xbot command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def set_auto_loading_zone_empty(
	auto_loading_zone_id: int
):
	"""set an auto loading zone as empty, so that the system can load the next XBot

	Parameters
	----------
	auto_loading_zone_id: int
		None

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(auto_loading_zone_id, int, "auto_loading_zone_id")
	


	rtn = __bot.SetAutoLoadingZoneEmpty(int(auto_loading_zone_id))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"set_auto_loading_zone_empty command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def get_auto_loading_zone_status(
	auto_loading_zone_id: int
):
	"""get the status of an auto loading/unloading zone

	Parameters
	----------
	auto_loading_zone_id: int
		auto loading zone ID

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(auto_loading_zone_id, int, "auto_loading_zone_id")
	


	rtn = __bot.GetAutoLoadingZoneStatus(int(auto_loading_zone_id))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_auto_loading_zone_status command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		pm.AutoLoadZoneStatus(
		pm.ALZONESTATE(int(rtn.alZoneStatus.ZoneState)),
		rtn.alZoneStatus.LoadedXBotID,
		rtn.alZoneStatus.ReadyForNextXBot,
		rtn.alZoneStatus.XBotCount,
		rtn.alZoneStatus.UnloadingEntryXposm,
		rtn.alZoneStatus.UnloadingEntryYposm

	)




def get_all_accident_xbots():
	"""Gets the ID and count of all xbots that have been deactivated due to accidents

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	

	rtn = __bot.GetAllAccidentXbots()

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"get_all_accident_xbots command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return pm.XBotIDs(
		pm.PMCRTN(int(rtn.PmcRtn)),
		rtn.XBotCount,
		[x for x in rtn.XBotIDsArray]

		)


def recover_accident_xbot(
	xbot_id: int,
	mode: pm.RECOVERXBOTMODE,
	option: pm.RECOVERXBOTOPTIONS
):
	"""Recovers the specified xbot after an accident

	Parameters
	----------
	xbot_id: int
		 ID of the Xbot to be recovered
	mode: pm.RECOVERXBOTMODE
		 Defines the behabiour of the Xbot after recovering
	option: pm.RECOVERXBOTOPTIONS
		Option For Short Axes Posotion After Recovering the XBot

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(xbot_id, int, "xbot_id")
	assert_type(mode, pm.RECOVERXBOTMODE, "mode")
	assert_type(option, pm.RECOVERXBOTOPTIONS, "option")
	
	mode_enum = PMCLIB.RECOVERXBOTMODE(mode)
	option_enum = PMCLIB.RECOVERXBOTOPTIONS(option)


	rtn = __bot.RecoverAccidentXbot(int(xbot_id),mode_enum,option_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"recover_accident_xbot command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def run_gcode(
	cmd_label: int,
	xbot_id: int,
	gcode_id: int
):
	"""Run g-code command

	Parameters
	----------
	cmd_label: int
		2 byte command label, converted to unsigned short
	xbot_id: int
		 ID of xbot to run g-code motion command with 
	gcode_id: int
		 ID of the g-code to run

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(cmd_label, int, "cmd_label")
	assert_type(xbot_id, int, "xbot_id")
	assert_type(gcode_id, int, "gcode_id")
	


	rtn = __bot.RunGCode(UInt16(cmd_label),int(xbot_id),int(gcode_id))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"run_gcode command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def create_xbot_tracking_failure(
	xbot_id: int,
	err_type: pm.TRACKINGFAILURETYPE
):
	"""Injects tracking errors failures to the specified XBot, useful for testing failure handling routines

	Parameters
	----------
	xbot_id: int
		 XBot ID to add tracking error failure to
	err_type: pm.TRACKINGFAILURETYPE
		 Type of tracking error failure to add

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(xbot_id, int, "xbot_id")
	assert_type(err_type, pm.TRACKINGFAILURETYPE, "err_type")
	
	err_type_enum = PMCLIB.TRACKINGFAILURETYPE(err_type)


	rtn = __bot.CreateXbotTrackingFailure(int(xbot_id),err_type_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"create_xbot_tracking_failure command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def rotary_motion_p2p(
	cmd_label: int,
	xbot_id: int,
	mode: pm.ROTATIONMODE,
	target_rz: float,
	target_rz_vel: float,
	target_rz_acc: float,
	position_mode: pm.POSITIONMODE
):
	"""Rz full Rotation to user specified angle

	Parameters
	----------
	cmd_label: int
		Rotation command label
	xbot_id: int
		Xbot ID to rotate
	mode: pm.ROTATIONMODE
		Rotation mode 
	target_rz: float
		 The target Rz to rotate to, in rad
	target_rz_vel: float
		 The target Rz angular velocity to rotate at, in rad/s
	target_rz_acc: float
		 The target Rz angular acceleration, in rad/s^2
	position_mode: pm.POSITIONMODE
		0 = absolute position mode; 1 = relative position mode

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(cmd_label, int, "cmd_label")
	assert_type(xbot_id, int, "xbot_id")
	assert_type(mode, pm.ROTATIONMODE, "mode")
	assert_type(target_rz, float, "target_rz")
	assert_type(target_rz_vel, float, "target_rz_vel")
	assert_type(target_rz_acc, float, "target_rz_acc")
	assert_type(position_mode, pm.POSITIONMODE, "position_mode")
	
	mode_enum = PMCLIB.ROTATIONMODE(mode)
	position_mode_enum = PMCLIB.POSITIONMODE(position_mode)


	rtn = __bot.RotaryMotionP2P(int(cmd_label),int(xbot_id),mode_enum,float(target_rz),float(target_rz_vel),float(target_rz_acc),position_mode_enum)

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"rotary_motion_p2p command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		rtn.TravelTimeSecs



def rotary_motion_timed_spin(
	cmd_label: int,
	xbot_id: int,
	target_final_rz: float,
	target_rz_vel: float,
	target_rz_acc: float,
	time_s: float
):
	"""Rotate the xbot around the Rz axis for a specified amount time

	Parameters
	----------
	cmd_label: int
		Rotation command label
	xbot_id: int
		Xbot ID to rotate
	target_final_rz: float
		 The final Rz position to finish rotation at, in rad
	target_rz_vel: float
		 The target Rz angular velocity to rotate at, in rad/s
	target_rz_acc: float
		 The target Rz angular acceleration, in rad/s^2
	time_s: float
		 The time to rotate for in s

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(cmd_label, int, "cmd_label")
	assert_type(xbot_id, int, "xbot_id")
	assert_type(target_final_rz, float, "target_final_rz")
	assert_type(target_rz_vel, float, "target_rz_vel")
	assert_type(target_rz_acc, float, "target_rz_acc")
	assert_type(time_s, float, "time_s")
	


	rtn = __bot.RotaryMotionTimedSpin(int(cmd_label),int(xbot_id),float(target_final_rz),float(target_rz_vel),float(target_rz_acc),float(time_s))

	if rtn.PmcRtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"rotary_motion_timed_spin command failed with code {rtn.PmcRtn}({Enum.GetName(PMCRTN, rtn.PmcRtn)})"
		)

	return 		rtn.TravelTimeSecs



def set_jerk_limit(
	xbot_id: int,
	axis: pm.JERKLIMAXIS,
	jerk_lim: float
):
	"""Set the jerk limit for a specific xbot and specific axis

	Parameters
	----------
	xbot_id: int
		 The xbot ID to set the jerk limit
	axis: pm.JERKLIMAXIS
		 The axis to set the jerk limit
	jerk_lim: float
		The jerk limit, in m/s^3

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(xbot_id, int, "xbot_id")
	assert_type(axis, pm.JERKLIMAXIS, "axis")
	assert_type(jerk_lim, float, "jerk_lim")
	
	axis_enum = PMCLIB.JERKLIMAXIS(axis)


	rtn = __bot.SetJerkLimit(int(xbot_id),axis_enum,float(jerk_lim))

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"set_jerk_limit command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def set_virtual_xbot_position(
	v_xbot_id: int,
	position_si: pm.SixDOFInfo
):
	"""Instantly set the position of a virtual xbot

	Parameters
	----------
	v_xbot_id: int
		The virtual xbot ID (100-127)
	position_si: pm.SixDOFInfo
		The 6DOF position to set the virtual xbot to

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(v_xbot_id, int, "v_xbot_id")
	assert_type(position_si, pm.SixDOFInfo, "position_si")
	
	position_si_enum = PMCLIB.SixDOFInfo()
	position_si_enum.X = position_si.x
	position_si_enum.Y = position_si.y
	position_si_enum.Z = position_si.z
	position_si_enum.Rx = position_si.rx
	position_si_enum.Ry = position_si.ry
	position_si_enum.Rz = position_si.rz



	rtn = __bot.SetVirtualXbotPosition(int(v_xbot_id),position_si_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"set_virtual_xbot_position command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def long_axis_jogging_control(
	xbot_id: int,
	x_speed: float,
	y_speed: float,
	operation: pm.JOGGINGOPERATION
):
	"""Jogs the mover on the XY coordinates

	Parameters
	----------
	xbot_id: int
		Mover ID
	x_speed: float
		X-Axis Speed (m/s)
	y_speed: float
		Y-Axis Speed (m/s)
	operation: pm.JOGGINGOPERATION
		Jogging Operation. Turns On or Turns Off the Jogging

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(xbot_id, int, "xbot_id")
	assert_type(x_speed, float, "x_speed")
	assert_type(y_speed, float, "y_speed")
	assert_type(operation, pm.JOGGINGOPERATION, "operation")
	
	operation_enum = PMCLIB.JOGGINGOPERATION(operation)


	rtn = __bot.LongAxisJoggingControl(int(xbot_id),float(x_speed),float(y_speed),operation_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"long_axis_jogging_control command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)


def short_axis_jogging_control(
	xbot_id: int,
	axis: pm.SHORTAXIS,
	speed: float,
	operation: pm.JOGGINGOPERATION
):
	"""Jogs the mover in a single direction in the Z, Rx, Ry or Rz axes

	Parameters
	----------
	xbot_id: int
		Mover ID
	axis: pm.SHORTAXIS
		Jogging Axis
	speed: float
		Jogging Speed (m/s) or (rad/s)
	operation: pm.JOGGINGOPERATION
		Jogging Operation. Turns On or Turns Off the Jogging

	Raises
	------
	pmc_types.PmcError
		 Raised when the command fails or is rejected by the PMC.
	"""
	assert_type(xbot_id, int, "xbot_id")
	assert_type(axis, pm.SHORTAXIS, "axis")
	assert_type(speed, float, "speed")
	assert_type(operation, pm.JOGGINGOPERATION, "operation")
	
	axis_enum = PMCLIB.SHORTAXIS(axis)
	operation_enum = PMCLIB.JOGGINGOPERATION(operation)


	rtn = __bot.ShortAxisJoggingControl(int(xbot_id),axis_enum,float(speed),operation_enum)

	if rtn != PMCRTN.ALLOK:
		raise pm.PmcError(
			f"short_axis_jogging_control command failed with code {rtn}({Enum.GetName(PMCRTN, rtn)})"
		)

