from enum import IntEnum
from typing import List
from typing import NamedTuple
from enum import Enum
import datetime
import PMCLIB


class PmcError(Exception):
	""" PMC Error Exception
	"""

	def __init__(self, *args : object) -> None:
		super().__init__(*args)


def assert_type(checkvar, checkType: type, varName: str=""):
	"""Assert the input variable is of the correct type

	Parameters
	----------
	var: Any
		Variable to check
	checkType : type
		Type that the variable is asserted to be
	varName : str
		Name of the variable
	"""

	if checkType == float and (type(checkvar) == int or type(checkvar) == float):
		return

	if type(checkvar) is not checkType:
		raise TypeError(
			f"{varName} expected {checkType}, got {type(checkvar)}")


class TRIGGERSOURCE(IntEnum):
	"""Enum for the source of the trigger for WaitUntil command

	Options
	----------
	TIME_DELAY:
		Time delay trigger mode
	EXTERNAL_DI:
		external digital input trigger mode
	FIELDBUS_DI:
		fieldbus digital input trigger mode
	CMD_LABEL:
		command label trigger mode
	DISPLACEMENT:
		displacement trigger mode
	"""
	TIME_DELAY = 0,
	EXTERNAL_DI = 1,
	FIELDBUS_DI = 2,
	CMD_LABEL = 3,
	DISPLACEMENT = 4,
	
class WAITUNTILSTARTOPTION(IntEnum):
	"""Enum for when the WaitUntil command should start monitoring

	Options
	----------
	STARTATEXECUTION:
		Starts monitoring when the command is executed (removed from the buffer)
	STARTATRECEIVED:
		Starts monitoring when the command is received (added in the buffer)
	SPECIFYSTARTCONDITION:
		Starts monitoring for the finish condition only after the specified start condition has been met
	"""
	STARTATEXECUTION = 0,
	STARTATRECEIVED = 1,
	SPECIFYSTARTCONDITION = 2,
	
class TRIGGEREDGETYPE(IntEnum):
	"""enum for possible trigger edge types for digital inputs

	Options
	----------
	RISING_EDGE:
		triggers on the rising edge
	FALLING_EDGE:
		triggers on the falling edge
	IS_ONE:
		triggers when source value is 1
	IS_ZERO:
		triggers when source value is 0
	"""
	RISING_EDGE = 0,
	FALLING_EDGE = 1,
	IS_ONE = 2,
	IS_ZERO = 3,
	
class TRIGGERCMDLABELTYPE(IntEnum):
	"""enum for when to trigger during command label delay method

	Options
	----------
	CMD_START:
		triggers at the start of command
	CMD_FINISH:
		triggers when the command has finished
	CMD_EXECUTING:
		triggers during command execution
	"""
	CMD_START = 0,
	CMD_FINISH = 1,
	CMD_EXECUTING = 2,
	
class TRIGGERCMDTYPE(IntEnum):
	"""enum for defining trigger command label's command type

	Options
	----------
	MOTION_COMMAND:
		The command is a standard motion command such as linear motion, arc motion, etc.
	RUNMACRO_COMMAND:
		The command is a run macro motion command
	"""
	MOTION_COMMAND = 0,
	RUNMACRO_COMMAND = 1,
	
class TRIGGERDISPLACEMENTTYPE(IntEnum):
	"""enum for trigger type during displacement trigger method

	Options
	----------
	GREATER_THAN:
		triggers when displacement (ax+by, or only x, or only y) is greater than threshold
	LESS_THAN:
		triggers when displacement (ax+by, or only x, or only y) is less than threshold
	POSITIVE_CROSS:
		triggers when going from less than threshold to greater than threshold
	NEGATIVE_CROSS:
		triggers when going from greater than threshold to less than threshold
	"""
	GREATER_THAN = 0,
	LESS_THAN = 1,
	POSITIVE_CROSS = 2,
	NEGATIVE_CROSS = 3,
	
class TRIGGERDISPLACEMENTMODE(IntEnum):
	"""enum for trigger mode during displacement trigger method

	Options
	----------
	X_ONLY:
		monitoring X position only
	Y_ONLY:
		monitoring Y position only
	AX_BY:
		monitoring by an arbitrary line
	"""
	X_ONLY = 0,
	Y_ONLY = 1,
	AX_BY = 2,
	
class FEEDBACKOPTION(IntEnum):
	"""Choose what the FeedbackPositionSI contains in GetXBotStatus

	Options
	----------
	POSITION:
		provides position data in the command reply
	FORCE:
		provides force data in the command reply
	REFERENCE:
		provides the current reference position data in the command reply
	TARGET = 5:
		provides the current target position data in the command reply
	REF_VELOCITY = 6:
		provides the reference velocity data in the command reply
	"""
	POSITION = 0,
	FORCE = 1,
	REFERENCE = 2,
	TARGET = 5,
	REF_VELOCITY = 6,
	
class ALLXBOTSFEEDBACKOPTION(IntEnum):
	"""Choose what the GetAllXbotInfo command returns

	Options
	----------
	POSITION:
		provides position data in the command reply
	REFERENCE:
		provides the current reference position data in the command reply
	"""
	POSITION = 0,
	REFERENCE = 1,
	
class FORCEMODEOPTION(IntEnum):
	"""Enum for which axis to enable open-loop force mode

	Options
	----------
	ZFORCE = 1:
		Open loop force mode in Z
	XFORCE = 2:
		Open loop force mode in X Axis
	YFORCE = 3:
		Open loop force mode in Y Axis
	XANDYFORCE = 4:
		Open loop force mode in X and Y Axis
	RZFORCE = 5:
		Open loop torque mode in Rz rotation Axis
	RXFORCE = 6:
		Open loop torque mode in Rx rotation Axis
	RYFORCE = 7:
		Open loop torque mode in Ry rotation Axis
	XANDRZFORCE = 8:
		Open loop torque mode in Rz and force mode in X
	YANDRZFORCE = 9:
		Open loop torque mode in Rz and force mode in Y
	RXRYANDZFORCE = 10:
		Open loop torque mode in Rx, Ry and force mode in Z
	XYANDRZFORCE = 11:
		Open loop torque mode in Rz and force mode in X and Y
	"""
	ZFORCE = 1,
	XFORCE = 2,
	YFORCE = 3,
	XANDYFORCE = 4,
	RZFORCE = 5,
	RXFORCE = 6,
	RYFORCE = 7,
	XANDRZFORCE = 8,
	YANDRZFORCE = 9,
	RXRYANDZFORCE = 10,
	XYANDRZFORCE = 11,
	
class FORCEMODETYPE(IntEnum):
	"""Enum for the Force Mode Type (Relative or Absolute)

	Options
	----------
	ABSOLUTE = 0:
		Absolute Force Mode
	RELATIVE:
		Relative Force Mode
	"""
	ABSOLUTE = 0,
	RELATIVE = 1,
	
class PMCRTN(IntEnum):
	"""reply from the PMC for a given command

	Options
	----------
	SAVE_FILE_FAILED = -3:
		An exception occurred while saving a file
	EXCEPTION = -2:
		An exception occurred, failed to send command
	NONETWORK = -1:
		No connection to PMC
	ALLOK = 0:
		Command accepted
	SYSTEMERROR = 0X0001:
		PMC failed to reply, please resend command
	WRONGPMCSTATE = 0x2000:
		PMC is in an incorrect state for this command. (For example, not activated)
	NOMASTERSHIP = 0x2001:
		Do not have the required mastership for this command
	MASTERSHIP_TIMEOUT = 0x2002:
		Mastership did not provide a response
	WRONG_GROUP_STATE = 0x2003:
		Group command rejected due to wrong group state
	WRONG_MACRO_STATE = 0x2004:
		Macro command rejected due to wrong macro state
	WRONG_DIGITAL_IO_STATE = 0x2005:
		Wrong digital input / output state
	WRONG_FLYWAY_STATE = 0x2006:
		wrong flyway state
	NO_ROUTING_SOLUTION = 0x2008:
		Failed to find a routing solution for auto driving
	COMMUNICATION_TIMEOUT = 0x2009:
		Internal communication timeout
	NO_LICENSE = 0x200A:
		Missing license
	UNDEFINED_STEREOTYPE = 0x200B:
		Mover stereotype is not defined
	EVENT_ID_BUSY = 0x200C:
		Command event ID is busy
	EVENT_BUFFER_FULL = 0x200D:
		Command event buffer is full
	CONFIG_BACKUP_FAILURE = 0x200F:
		User configuration backup failure
	CONFIG_READING_FAILURE = 0x2010:
		User configuration reading failure
	FILE_OPEN_FAILURE = 0x2011:
		File open failure
	GCODE_SAVE_FAILURE = 0x2012:
		Save G-code failure
	INVALID_GCODE = 0x2013:
		Invalid G-code
	NO_SCANNING_SOLUTION = 0x2014:
		No auto XID scanning solution found
	INTERNAL_COMMAND_ERROR = 0x2015:
		Internal command error
	WRONGXBOTSTATE = 0x3000:
		Xbot state incorrect for this command. (For example, not levitated)
	WRONGXBOTPOSITION = 0x3001:
		XBot position is incorrect for this command. (For Rz Rotation)
	XBOT_WEIGHING_TIMEOUT = 0x3002:
		XBot weighing timeout
	WRONG_XBOT_TYPE = 0x3004:
		Wrong xbot type for full rotation
	INVALIDPARAMS = 0x4000:
		Parameters for this command are invalid
	INVALID_XML = 0x4001:
		Invalid XML file
	INVALID_WIRING = 0x4002:
		Invalid PMNet wiring
	WRONG_QUEUE_STATE = 0x5000:
		Wrong queue state
	WRONG_ZONE_STATE = 0x5001:
		The zone is in the wrong state to perform this operation
	ZONE_NOT_AVAILABLE = 0x5002:
		An XBot is located on the zone boundary
	WRONG_AL_ZONE_STATE = 0x5003:
		Wrong auto-loading/unloading zone state
	WRONG_TRAFFICROAD_STATE = 0x5004:
		Wrong traffic road state
	WRONG_STARWHEEL_STATE = 0x5005:
		Wrong star wheel state
	FUNCTION_BUFFER_FULL = 0x5006:
		Function buffer is full
	RUN_FUNCTION_FAILURE = 0x5007:
		Run function failure
	WRONG_SECTOR_STATE = 0x5008:
		Wrong sector state
	SECTOR_NOT_AVALIABLE = 0x5009:
		Sector not available
	TRACE_NOT_DEFINED = 0x6000:
		Trace not defined
	INVALID_TRACE = 0x6001:
		Invalid trace
	TRACE_NOT_READY = 0x6002:
		Trace is not ready
	CODE_GENERATION_ONLY = 0xFFFE:
		Only used for code generation, not an actual command for the PMC
	INVALIDCOMMAND = 0xFFFF:
		The command ID is invalid
	"""
	SAVE_FILE_FAILED = -3,
	EXCEPTION = -2,
	NONETWORK = -1,
	ALLOK = 0,
	SYSTEMERROR = 0X0001,
	WRONGPMCSTATE = 0x2000,
	NOMASTERSHIP = 0x2001,
	MASTERSHIP_TIMEOUT = 0x2002,
	WRONG_GROUP_STATE = 0x2003,
	WRONG_MACRO_STATE = 0x2004,
	WRONG_DIGITAL_IO_STATE = 0x2005,
	WRONG_FLYWAY_STATE = 0x2006,
	NO_ROUTING_SOLUTION = 0x2008,
	COMMUNICATION_TIMEOUT = 0x2009,
	NO_LICENSE = 0x200A,
	UNDEFINED_STEREOTYPE = 0x200B,
	EVENT_ID_BUSY = 0x200C,
	EVENT_BUFFER_FULL = 0x200D,
	CONFIG_BACKUP_FAILURE = 0x200F,
	CONFIG_READING_FAILURE = 0x2010,
	FILE_OPEN_FAILURE = 0x2011,
	GCODE_SAVE_FAILURE = 0x2012,
	INVALID_GCODE = 0x2013,
	NO_SCANNING_SOLUTION = 0x2014,
	INTERNAL_COMMAND_ERROR = 0x2015,
	WRONGXBOTSTATE = 0x3000,
	WRONGXBOTPOSITION = 0x3001,
	XBOT_WEIGHING_TIMEOUT = 0x3002,
	WRONG_XBOT_TYPE = 0x3004,
	INVALIDPARAMS = 0x4000,
	INVALID_XML = 0x4001,
	INVALID_WIRING = 0x4002,
	WRONG_QUEUE_STATE = 0x5000,
	WRONG_ZONE_STATE = 0x5001,
	ZONE_NOT_AVAILABLE = 0x5002,
	WRONG_AL_ZONE_STATE = 0x5003,
	WRONG_TRAFFICROAD_STATE = 0x5004,
	WRONG_STARWHEEL_STATE = 0x5005,
	FUNCTION_BUFFER_FULL = 0x5006,
	RUN_FUNCTION_FAILURE = 0x5007,
	WRONG_SECTOR_STATE = 0x5008,
	SECTOR_NOT_AVALIABLE = 0x5009,
	TRACE_NOT_DEFINED = 0x6000,
	INVALID_TRACE = 0x6001,
	TRACE_NOT_READY = 0x6002,
	CODE_GENERATION_ONLY = 0xFFFE,
	INVALIDCOMMAND = 0xFFFF,
	
class XBOTSTATE(IntEnum):
	"""XBot state enum

	Options
	----------
	XBOT_PREVIEW = -2:
		Reserved
	XBOT_UNKNOWN = -1,  # for when the xbotstate hasn't been read:
		unable to determine XBOT state
	XBOT_UNDETECTED = 0:
		XBot not detected by the PMC
	XBOT_DISCOVERING:
		XBOT is landed
	XBOT_LANDED:
		XBOT is landed
	XBOT_IDLE:
		XBOT is idling (levitated)
	XBOT_DISABLED:
		XBOT is disabled
	XBOT_MOTION:
		XBOT is in motion
	XBOT_WAIT:
		XBOT is waiting for a trigger
	XBOT_STOPPING:
		XBOT is attempting to stop
	XBOT_OBSTACLE_DETECTED:
		XBOT detected an obstacle and is waiting for obstacle to clear
	XBOT_HOLDPOSITION:
		XBOT is hold position due excessive error during motion
	XBOT_STOPPED:
		XBOT stopped and will not automatically resume
	XBOT_RESERVED:
		XBOT is in stream motion
	XBOT_RESERVED1:
		XBOT is in asynchronous motion (automatically driven to target)
	XBOT_RESERVED2:
		reserved
	XBOT_ERROR:
		XBOT has an error
	XBOT_UNINSTALLED:
		XBOT is not installed
	"""
	XBOT_PREVIEW = -2,
	XBOT_UNKNOWN = -1,  # for when the xbotstate hasn't been read,
	XBOT_UNDETECTED = 0,
	XBOT_DISCOVERING = 1,
	XBOT_LANDED = 2,
	XBOT_IDLE = 3,
	XBOT_DISABLED = 4,
	XBOT_MOTION = 5,
	XBOT_WAIT = 6,
	XBOT_STOPPING = 7,
	XBOT_OBSTACLE_DETECTED = 8,
	XBOT_HOLDPOSITION = 9,
	XBOT_STOPPED = 10,
	XBOT_RESERVED = 11,
	XBOT_RESERVED1 = 12,
	XBOT_RESERVED2 = 13,
	XBOT_ERROR = 14,
	XBOT_UNINSTALLED = 15,
	
class PMCSTATUS(IntEnum):
	"""PMC Status Enum

	Options
	----------
	PMC_UNKNOWN = -1:
		Unable to determine PMC Status
	PMC_BOOTING = 0:
		PMC is booting up
	PMC_INACTIVE:
		PMC is inactive (XBOTs deactivated)
	PMC_ACTIVATING:
		PMC is starting to activate
	PMC_DISCOVERY:
		Movers are scanning for Absolute ID
	PMC_SERVICE:
		Reserved
	PMC_FULLCTRL:
		PMC in fully controlled mode
	PMC_INTELLIGENTCTRL:
		PMC in intelligent control mode
	PMC_DEACTIVATING:
		PMC is deactivating
	PMC_ERRORHANDLING:
		PMC is handling an error and recording snapshots
	PMC_ERROR:
		PMC is in the error state
	"""
	PMC_UNKNOWN = -1,
	PMC_BOOTING = 0,
	PMC_INACTIVE = 1,
	PMC_ACTIVATING = 2,
	PMC_DISCOVERY = 3,
	PMC_SERVICE = 4,
	PMC_FULLCTRL = 5,
	PMC_INTELLIGENTCTRL = 6,
	PMC_DEACTIVATING = 7,
	PMC_ERRORHANDLING = 8,
	PMC_ERROR = 9,
	
class BORDERSTATUS(IntEnum):
	"""Multi-PMC Border Status Enum

	Options
	----------
	DISCONNECTED = 0:
		The flyway link between this border is not connected
	NOTREADY:
		The flyway link between this border is connected, but it is not yet ready to receive xbots
	READY:
		The flyway link at this border is connected and it is ready to receive xbots
	"""
	DISCONNECTED = 0,
	NOTREADY = 1,
	READY = 2,
	
class POSITIONMODE(IntEnum):
	"""Motion position mode Enum

	Options
	----------
	ABSOLUTE = 0:
		Absolute positioning
	RELATIVE:
		Relative positioning
	"""
	ABSOLUTE = 0,
	RELATIVE = 1,
	
class CAMMODE(IntEnum):
	"""Can choose between

	Options
	----------
	AutoStart = 0:
		automatically trigger the cam motion when the master xbot is inside the cam region
	Cyclic = 1:
		the profile is unwound and repeats cyclicly, such that the cam profile covers the range from -infinity to + infinity for the master axis
	SingleStart = 2:
		the cam stops automatically if the master axis exits the defined cam region, and does not start again if the master axis re-enters the cam region
	"""
	AutoStart = 0,
	Cyclic = 1,
	SingleStart = 2,
	
class CAMRATCHETDIRECTION(IntEnum):
	"""Select the cam engagement direction

	Options
	----------
	BOTH_DIRECTIONS = 0:
		The cam is engaged whether the master axis value is changing in the forward (positive) or backward (negative) direction
	"""
	BOTH_DIRECTIONS = 0,
	
class LINEARPATHTYPE(IntEnum):
	"""Linear path type Enum

	Options
	----------
	DIRECT = 0:
		Direct motion
	XTHENY:
		X motion first, then Y motion
	YTHENX:
		Y motion first, then X motion
	"""
	DIRECT = 0,
	XTHENY = 1,
	YTHENX = 2,
	
class ARCDIRECTION(IntEnum):
	"""Arc direction Enum

	Options
	----------
	CLOCKWISE = 0:
		Clockwise motion
	COUNTERCLOCKWISE:
		Counter-clockwise motion
	"""
	CLOCKWISE = 0,
	COUNTERCLOCKWISE = 1,
	
class ARCTYPE(IntEnum):
	"""Arc type Enum

	Options
	----------
	MINORARC = 0:
		Minor arc
	MAJORARC:
		Major arc
	"""
	MINORARC = 0,
	MAJORARC = 1,
	
class ARCMODE(IntEnum):
	"""Arc motion mode Enum

	Options
	----------
	TARGETRADIUS = 0:
		Target + radius mode
	CENTERANGLE:
		Center + angle mode
	"""
	TARGETRADIUS = 0,
	CENTERANGLE = 1,
	
class MOTIONBUFFEROPTIONS(IntEnum):
	"""Motion buffer options Enum

	Options
	----------
	BLOCKBUFFER = 0:
		Block motion buffer
	RELEASEBUFFER:
		Release motion buffer
	CLEARBUFFER:
		Clear motion buffer
	"""
	BLOCKBUFFER = 0,
	RELEASEBUFFER = 1,
	CLEARBUFFER = 2,
	
class MOTIONMACROOPTIONS(IntEnum):
	"""Motion macro options Enum

	Options
	----------
	CLEARMACRO = 0:
		Clear motion macro
	SAVEMACRO = 2:
		Finish motion macro editing
	QUERYSTATUS = 4:
		Query status of macro
	"""
	CLEARMACRO = 0,
	SAVEMACRO = 2,
	QUERYSTATUS = 4,
	
class GROUPOPTIONS(IntEnum):
	"""Group options Enum

	Options
	----------
	CREATEGROUP = 0:
		Create group
	DELETEGROUP:
		Delete group
	BONDGROUP:
		Connect group
	UNBONDGROUP:
		Disconnect group
	BLOCKMEMBERSBUFFER:
		Block motion buffer for group
	RELEASEMEMBERSBUFFER:
		Unblock motion buffer for group
	QUERYSTATUS:
		Query group status
	"""
	CREATEGROUP = 0,
	DELETEGROUP = 1,
	BONDGROUP = 2,
	UNBONDGROUP = 3,
	BLOCKMEMBERSBUFFER = 4,
	RELEASEMEMBERSBUFFER = 5,
	QUERYSTATUS = 6,
	
class LEVITATEOPTIONS(IntEnum):
	"""Levitation options Enum

	Options
	----------
	LAND = 0:
		Land XBOT
	LEVITATE:
		Levitate XBOT
	"""
	LAND = 0,
	LEVITATE = 1,
	
class LEVITATIONSPEED(IntEnum):
	"""Levitation speed options enum

	Options
	----------
	APPROX_1600MS = 0:
		Levitate/Land the xbot(s) in roughly 1.6s
	APPROX_800MS:
		Levitate/Land the xbot(s) in roughly 0.8s
	APPROX_400MS:
		Levitate/Land the xbot(s) in roughly 0.4s
	APPROX_200MS:
		Levitate/Land the xbot(s) in roughly 0.2s
	APPROX_100MS:
		Levitate/Land the xbot(s) in roughly 0.1s
	APPROX_50MS:
		Levitate/Land the xbot(s) in roughly 0.05s
	"""
	APPROX_1600MS = 0,
	APPROX_800MS = 1,
	APPROX_400MS = 2,
	APPROX_200MS = 3,
	APPROX_100MS = 4,
	APPROX_50MS = 5,
	
class MOBILITYOPTIONS(IntEnum):
	"""Mobility options enums

	Options
	----------
	DISABLE = 0:
		Disable XBOT
	LAND = 1:
		Land XBOT
	LEVITATE = 2:
		Levitate XBOT
	"""
	DISABLE = 0,
	LAND = 1,
	LEVITATE = 2,
	
class MOTIONINTERRUPTOPTIONS(IntEnum):
	"""motion interrupt options Enum

	Options
	----------
	RESUME = 0:
		Resume the xbot motion
	PAUSE:
		pause the xbot motion
	"""
	RESUME = 0,
	PAUSE = 1,
	
class ASYNCOPTIONS(IntEnum):
	"""Async motion options Enum

	Options
	----------
	MOVEALL = 0:
		All XBOTs on flyways can be moved
	MOVEALL_UNLABELED = 1:
		Any mover can go to any of the specified target positions
	"""
	MOVEALL = 0,
	MOVEALL_UNLABELED = 1,
	
class PLANETOPTIONS(IntEnum):
	"""Planet Motion Enum

	Options
	----------
	REMOVEPLANETS = 0:
		Remove the planet XBOTs listed in this command from the sun XBOT's planet list
	ADDPLANETS:
		add the planet XBOTs listed in this command to the sun XBOT's planet list
	"""
	REMOVEPLANETS = 0,
	ADDPLANETS = 1,
	
class MOVERTYPE(IntEnum):
	"""Mover type enumeration

	Options
	----------
	M3_06=0:
		M3-06 120mm x 120mm
	RESERVED1:
		Reserved
	M3_08X:
		M3-08 180mm x 120mm
	M3_08Y:
		M3-08 120mm x 180mm
	M3_09X:
		Reserved
	M3_09Y:
		Reserved
	M3_10:
		M3-10 180mm x 180mm
	RESERVED7:
		Reserved
	M3_11X:
		M3-11 210mm x 180mm
	M3_11Y:
		M3-11 180mm x 210mm
	RESERVED10:
		Reserved
	RESERVED11:
		Reserved
	M3_12:
		M3-12 210mm x 210mm
	RESERVED13:
		Reserved
	M3_13:
		M3-13 240mm x 240mm
	RESERVED15:
		Reserved
	M3_15X:
		M3-15 330mm x 210mm
	M3_15Y:
		M3-15 210mm x 330mm
	M3_17:
		M3-17 300mm x 300mm
	RESERVED19:
		Reserved
	M3_18:
		M3-18 330mm x 330mm
	RESERVED21:
		Reserved
	M3_25:
		M325 XBot 450x450x16 mm
	RESERVED23:
		Reserved
	"""
	M3_06=0,
	RESERVED1 = 1,
	M3_08X = 2,
	M3_08Y = 3,
	M3_09X = 4,
	M3_09Y = 5,
	M3_10 = 6,
	RESERVED7 = 7,
	M3_11X = 8,
	M3_11Y = 9,
	RESERVED10 = 10,
	RESERVED11 = 11,
	M3_12 = 12,
	RESERVED13 = 13,
	M3_13 = 14,
	RESERVED15 = 15,
	M3_15X = 16,
	M3_15Y = 17,
	M3_17 = 18,
	RESERVED19 = 19,
	M3_18 = 20,
	RESERVED21 = 21,
	M3_25 = 22,
	RESERVED23 = 23,
	
class MOVERPROPERTY(IntEnum):
	"""Enum containing the index of mover properties

	Options
	----------
	INVALIDPROPERTY = -1:
		invalid mover property
	MOVERTYPE_0 = 0:
		Mover type
	PAYLOADKG_1:
		Configure payload on the mover, in kg
	CGHEIGHTM_2:
		the height of the center of gravity of the payload, in meters
	XDIMENSIONM_3:
		The max size of the payload or the mover, in the X direction, whichever is larger
	RESERVED_4:
		Reserved for future use
	YDIMENSIONM_5 = 5:
		The max size of the payload or the mover, in the Y direction, whichever is larger
	RESERVED2_6:
		Reserved for future use
	MAXACCELERATION_7 = 7:
		The maximum acceleration achievable by the mover, with the currently configured payload
	"""
	INVALIDPROPERTY = -1,
	MOVERTYPE_0 = 0,
	PAYLOADKG_1 = 1,
	CGHEIGHTM_2 = 2,
	XDIMENSIONM_3 = 3,
	RESERVED_4 = 4,
	YDIMENSIONM_5 = 5,
	RESERVED2_6 = 6,
	MAXACCELERATION_7 = 7,
	
class AXISNAMES(IntEnum):
	"""Axis enum, base 1

	Options
	----------
	NoAxis_0:
		No axis selected
	X_1 = 1:
		X Axis = 1
	Y_2:
		Y Axis = 2
	Z_3:
		Z Axis = 3
	RX_4:
		RX Axis = 4
	RY_5:
		RY Axis = 5
	RZ_6:
		RZ Axis = 6
	"""
	NoAxis_0 = 0,
	X_1 = 1,
	Y_2 = 2,
	Z_3 = 3,
	RX_4 = 4,
	RY_5 = 5,
	RZ_6 = 6,
	
class CAMOPTIONS(IntEnum):
	"""cam motion enum

	Options
	----------
	STOP_CAM = 0:
		Stop cam motion
	START_CAM:
		Start cam motion
	"""
	STOP_CAM = 0,
	START_CAM = 1,
	
class GROUPBONDOPTIONS(IntEnum):
	"""Group Bond Option Enum

	Options
	----------
	SIXDOF_DECOUPLED = 0:
		6D bonded, but xy is decoupled from RZ
	SIXDOF_COUPLED:
		6D bonded, but xy is coupled with RZ
	"""
	SIXDOF_DECOUPLED = 0,
	SIXDOF_COUPLED = 1,
	
class SHORTAXESCENTERMODE(IntEnum):
	"""short axes center mode Enum

	Options
	----------
	XBOT_CENTER = 0:
		XBOT center is used for rotation or tilt calculations
	USER_DEFINED_CENTER_XY:
		User defines the center (x,y coordinates) that the XBOT rotates around
	"""
	XBOT_CENTER = 0,
	USER_DEFINED_CENTER_XY = 1,
	
class ZONESTATE(IntEnum):
	"""Zone state

	Options
	----------
	UNKNOWN = -1:
		Unknown zone state
	UNDEFINED = 0:
		The zone has not been defined and cannot be used
	ACTIVATED_UNFENCED = 1:
		The zone is activated, XBots can move freely inside the zone and may move across the zone boundary
	DEACTIVATING = 2:
		The zone is deactivating. Any XBots inside the zone are in the process of being deactivated
	LOADING_FENCED = 3:
		The zone is a loading / unloading zone, a user may add or remove XBots from the zone manually. The XBots inside the zone are deactivated. XBots may not move across the zone boundary
	ACTIVATING = 4:
		The zone is activating. Any XBots inside the zone are in the process of being discovered / levitated
	ACTIVATED_FENCED = 5:
		The zone is activated, XBots can move freely inside the zone, but may not move across the zone boundary
	ERROR = 6:
		The zone is in error, XBots are not able to be detected in the zone
	LANDED = 7:
		The zone is activating, movers are being controlled in 3DOF
	LEVITATED = 8:
		The zone is activating, movers are being controlled in 6DOF weakly
	DISCOVER = 9:
		The zone is activating, movers are currently scanning for absolute ID
	"""
	UNKNOWN = -1,
	UNDEFINED = 0,
	ACTIVATED_UNFENCED = 1,
	DEACTIVATING = 2,
	LOADING_FENCED = 3,
	ACTIVATING = 4,
	ACTIVATED_FENCED = 5,
	ERROR = 6,
	LANDED = 7,
	LEVITATED = 8,
	DISCOVER = 9,
	
class ZONEOPERATION(IntEnum):
	"""zone operation performed by the Zone Control command. 0 = Deactivate Zone, 1= Activate Zone

	Options
	----------
	DEACTIVATE_ZONE = 0:
		Deactivate the zone, if successful, the zone is converted into a loading/unloading zone. Any XBots inside the zone will become deactivated
	ACTIVATE_ZONE = 1:
		Activated the zone, if successful, the zone is converted into a fenced active zone. Any XBots inside the zone will be levitated
	"""
	DEACTIVATE_ZONE = 0,
	ACTIVATE_ZONE = 1,
	
class FENCEOPERATION(IntEnum):
	"""fence operation performed by the Zone Fence Control command. 0 = remove fence around the zone, 1= build fence around the zone

	Options
	----------
	REMOVE_FENCE = 0:
		remove the fence around the zone, XBots can freely move across the zone boundary
	BUILD_FENCE = 1:
		build the fence around the zone, XBots cannot move across the zone boundary
	"""
	REMOVE_FENCE = 0,
	BUILD_FENCE = 1,
	
class QUEUEOPERATION(IntEnum):
	"""queue operation performed by the Queue Control Command. 0=create queue, 1=delete queue

	Options
	----------
	CREATE_QUEUE = 0:
		Create a queue, queue definitions are required
	DELETE_QUEUE = 1:
		Delete the queueing area
	"""
	CREATE_QUEUE = 0,
	DELETE_QUEUE = 1,
	
class AREASELECTION(IntEnum):
	"""select an area of the region to use

	Options
	----------
	BOTTOM_LEFT = 0:
		An area located at the bottom left corner of the queue, with the same size as the largest allowable XBot inside the area
	TOP_LEFT = 1:
		An area located at the top left corner of the queue, with the same size as the largest allowable XBot inside the area
	TOP_RIGHT = 2:
		An area located at the top right corner of the queue, with the same size as the largest allowable XBot inside the area
	BOTTOM_RIGHT = 3:
		An area located at the bottom right corner of the queue, with the same size as the largest allowable XBot inside the area
	"""
	BOTTOM_LEFT = 0,
	TOP_LEFT = 1,
	TOP_RIGHT = 2,
	BOTTOM_RIGHT = 3,
	
class ALZONEOPERATION(IntEnum):
	"""operation performed by the auto loading zone control command

	Options
	----------
	CREATE_AUTOLOAD_ZONE = 0:
		Create a autoload zone
	DELETE_AUTOLOAD_ZONE = 1:
		Delete the auto load zone
	ACTIVATE_AUTOLOAD_ZONE = 2:
		Activate the auto load zone
	DEACTIVATE_AUTOLOAD_ZONE = 3:
		Deactivate the auto load zone
	"""
	CREATE_AUTOLOAD_ZONE = 0,
	DELETE_AUTOLOAD_ZONE = 1,
	ACTIVATE_AUTOLOAD_ZONE = 2,
	DEACTIVATE_AUTOLOAD_ZONE = 3,
	
class ALZONETYPE(IntEnum):
	"""define the auto loading zone as either loading or unloading

	Options
	----------
	UNLOAD_ZONE = 0:
		unload from flyway zone, send XBot to external device
	LOAD_ZONE = 1:
		load to flyway zone, receive XBot from external device
	"""
	UNLOAD_ZONE = 0,
	LOAD_ZONE = 1,
	
class ALZONESTATE(IntEnum):
	"""configured auto loading zone state

	Options
	----------
	UNDEFINED = 0:
		auto loading zone has not been defined
	DEFINED = 1:
		auto loading zone has been defined
	UNLOADING_ZONE = 2:
		defined as auto unloading zone (removing XBot from flyway)
	LOADING_ZONE = 3:
		defined as auto loading zone (adding XBot to flyway)
	"""
	UNDEFINED = 0,
	DEFINED = 1,
	UNLOADING_ZONE = 2,
	LOADING_ZONE = 3,
	
class ALZONEUNLOADMODE(IntEnum):
	"""loading and unloading behaviour

	Options
	----------
	STOP_BEFORE_UNLOAD = 0:
		XBot will come to a stop at the boundary before the unload operation, for loading it will load the mover automatically
	NONSTOP_UNLOAD = 1:
		XBot will not stop but smoothly transition its motion into an unload operation
	MANUAL_UNLOAD = 2:
		XBot will be disabled allowing operator to unload manually, for loading it allows operator to load manually
	"""
	STOP_BEFORE_UNLOAD = 0,
	NONSTOP_UNLOAD = 1,
	MANUAL_UNLOAD = 2,
	
class MOTIONDIRECTION(IntEnum):
	"""XBot motion direction

	Options
	----------
	POSITIVE_X = 0:
		XBot will move in the +X direction
	NEGATIVE_X = 1:
		XBot will move in the -X direction
	POSITIVE_Y = 2:
		XBot will move in the +Y direction
	NEGATIVE_Y = 3:
		XBot will move in the -Y direction
	"""
	POSITIVE_X = 0,
	NEGATIVE_X = 1,
	POSITIVE_Y = 2,
	NEGATIVE_Y = 3,
	
class TRACKINGFAILURETYPE(IntEnum):
	"""Type of tracking error

	Options
	----------
	FATAL_TRACKING_ERR = 0:
		Fatal Tracking error
	SELF_RECOVERABLE_ERR:
		Self-recovering tracking error
	"""
	FATAL_TRACKING_ERR = 0,
	SELF_RECOVERABLE_ERR = 1,
	
class NOISEOPERATION(IntEnum):
	"""Noise operation performed by the Noise Control Command. 0=turn off, 1=turn on

	Options
	----------
	NOISE_OFF = 0:
		Turn off noise
	NOISE_ON = 1:
		Turn on noise, noise definition are required
	"""
	NOISE_OFF = 0,
	NOISE_ON = 1,
	
class NOISETYPE(IntEnum):
	"""Noise type used as one of noise parameters. 0=sinusoidal wave, 1=white

	Options
	----------
	SINUSOIDAL_WAVE = 0:
		Sinusoidal wave
	WHITE_NOISE = 1:
		White noise
	"""
	SINUSOIDAL_WAVE = 0,
	WHITE_NOISE = 1,
	
class TriState(IntEnum):
	"""failure (false), success (true), or unknown

	Options
	----------
	FALSE = -1:
		false, or failure
	TRUE:
		true, or success
	Unknown:
		unknown status
	"""
	FALSE = -1,
	TRUE = 0,
	Unknown = 1,
	
class XBOTTYPE(IntEnum):
	"""Current supported XBot Types

	Options
	----------
	M306 = 0:
		M306 XBot 120x120x10 mm
	M308X = 2:
		M308X XBot 180x120x10 mm
	M308Y = 3:
		M308Y XBot 120x180x10 mm
	M309X = 4:
		M309X XBot 240x120x10 mm
	M309Y = 5:
		M309Y XBot 120x240x10 mm
	M310 = 6:
		M310 XBot 180x180x10 mm
	M311X = 8:
		M311X XBot 210x180x10 mm
	M311Y = 9:
		M311Y XBot 180x210x10 mm
	M312 = 12:
		M312 XBot 210x210x10 mm
	M313 = 14:
		M313 XBot 240x240x10 mm
	M315X = 16:
		M315X XBot 330x210x12 mm
	M315Y = 17:
		M315Y XBot 210x330x12 mm
	M317 = 18:
		M317 XBot 300x300x12 mm
	M318 = 20:
		M318 XBot 330x330x12 mm
	M325 = 22:
		M325 XBot 450x450x16 mm
	"""
	M306 = 0,
	M308X = 2,
	M308Y = 3,
	M309X = 4,
	M309Y = 5,
	M310 = 6,
	M311X = 8,
	M311Y = 9,
	M312 = 12,
	M313 = 14,
	M315X = 16,
	M315Y = 17,
	M317 = 18,
	M318 = 20,
	M325 = 22,
	
class ROTATIONMODE(IntEnum):
	"""Rotary motion P2P mode

	Options
	----------
	NO_ANGLE_WRAP = 0:
		No angle wrap, directly rotate to target Rz
	WRAP_TO_2PI_CCW = 1:
		Wrap angle from [0, 2PI], rotate in the Counter Clockwise direction
	WRAP_TO_2PI_CW = -1:
		Wrap angle from [0, 2PI], rotate in the Clockwise Direction
	"""
	NO_ANGLE_WRAP = 0,
	WRAP_TO_2PI_CCW = 1,
	WRAP_TO_2PI_CW = -1,
	
class JERKLIMAXIS(IntEnum):
	"""Enum for selecting which axis to set the new jerk limit

	Options
	----------
	X = 1:
		X Axis Jerk Limit
	Z = 3:
		Z Axis Jerk Limit
	Rx = 4:
		Rx Axis Jerk Limit
	Ry = 5:
		Ry Axis Jerk Limit
	Rz = 6:
		RZ Axis Jerk Limit
	"""
	X = 1,
	Z = 3,
	Rx = 4,
	Ry = 5,
	Rz = 6,
	
class RECOVERXBOTMODE(IntEnum):
	"""Enum for selecting Xbot behaviour after recovering accident Xbot

	Options
	----------
	RESUME = 0:
		Resumes the previous motion after recovering the Xbot
	PAUSE = 1:
		Pauses the previous motion after recovering the Xbot
	STOP = 2:
		Clears the buffer after recovering the Xbot
	"""
	RESUME = 0,
	PAUSE = 1,
	STOP = 2,
	
class SECTORSTATE(IntEnum):
	"""Sector State

	Options
	----------
	UNKNOWN = -1:
		Unknown Sector State
	NOT_DEFINED = 0:
		Sector is Not Defined
	DISCONNECTED = 1:
		Sector Disconnected
	INACTIVE_FENCED = 2:
		Sector is Inactive and Fenced
	DEACTIVATING = 3:
		Sector Deactivating
	STOPPING = 4:
		Sector Stopping
	ACTIVATING = 5:
		Sector Activating
	ACTIVATED_FENCED = 6:
		Sector is Activated and Fenced
	OPERATION = 7:
		Sector in Operaation
	"""
	UNKNOWN = -1,
	NOT_DEFINED = 0,
	DISCONNECTED = 1,
	INACTIVE_FENCED = 2,
	DEACTIVATING = 3,
	STOPPING = 4,
	ACTIVATING = 5,
	ACTIVATED_FENCED = 6,
	OPERATION = 7,
	
class SECTOROPERATION(IntEnum):
	"""sector operation performed by the sector Control command. 0 = Deactivate Sector, 1= Activate Sector

	Options
	----------
	DEACTIVATE_SECTOR = 0:
		Deactivate the sector
	ACTIVATE_SECTOR = 1:
		Activated the sector
	"""
	DEACTIVATE_SECTOR = 0,
	ACTIVATE_SECTOR = 1,
	
class RECOVERXBOTOPTIONS(IntEnum):
	"""Options for the short axes position after recovering XBot

	Options
	----------
	DEFAULT = 0:
		Levitates XBot to Default Short Axes Position
	RESUME_PREV_SHORT_AXES = 1:
		Levitates XBot to Previous Short Axes Position
	"""
	DEFAULT = 0,
	RESUME_PREV_SHORT_AXES = 1,
	
class ASSIGNSTEREOTYPEOPTION(IntEnum):
	"""Options for the assign stereotype command

	Options
	----------
	IMMEDIATE = 0:
		Assign stereotype immediately
	SENDTOBUFFER = 1:
		Send assign stereotype command to the buffer
	"""
	IMMEDIATE = 0,
	SENDTOBUFFER = 1,
	
class JOGGINGOPERATION(IntEnum):
	"""Jogging operation performed by the Jogging Control Command. 0 = Turn Off, 1 = Turn On

	Options
	----------
	JOGGING_OFF = 0:
		Turn off jogging
	JOGGING_ON = 1:
		Turn on jogging
	"""
	JOGGING_OFF = 0,
	JOGGING_ON = 1,
	
class SHORTAXIS(IntEnum):
	"""Short Axis

	Options
	----------
	Z = 3:
		Z Axis
	RX = 4:
		RX Axis
	RY = 5:
		RY Axis
	RZ = 6:
		RZ Axis
	"""
	Z = 3,
	RX = 4,
	RY = 5,
	RZ = 6,
	
class LOGTYPE(IntEnum):
	"""Log Type (Warning or Error Log)

	Options
	----------
	ALL_LOG = 0:
		Both warning and error logs
	WARNING_LOG = 1:
		Warning log
	ERROR_LOG = 2:
		Error log
	"""
	ALL_LOG = 0,
	WARNING_LOG = 1,
	ERROR_LOG = 2,
	
class MotionRtn(NamedTuple):
	"""return struct for motion commands, includes PMC return + travel time

	Members
	----------
	PmcRtn: PMCRTN
		PMC return for the motion command
	travel_time_secs: float
		travelling time for the command, in seconds
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	travel_time_secs: float = 0.0
	

class BorderStatusRtn(NamedTuple):
	"""Return information for PMC border status

	Members
	----------
	PmcRtn: PMCRTN
		PMC command return for the border status query command
	border_status: BORDERSTATUS
		The status of the border
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	border_status: BORDERSTATUS = BORDERSTATUS(0)
	

class GCodeIDRtn(NamedTuple):
	"""Return information for G-code IDs

	Members
	----------
	PmcRtn: PMCRTN
		PMC command return for the command
	gcode_count: int
		The number of g-code IDs currently stored
	gcode_ids: List[int]
		An array of all g-code IDs currently stored in the PMC
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	gcode_count: int = 0
	gcode_ids: List[int] = None
	

class GCodeRtn(NamedTuple):
	"""Get G-Code command return

	Members
	----------
	PmcRtn: PMCRTN
		PMC command return for the command
	gcode_text: str
		The g-code text obtained by the command
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	gcode_text: str = None
	

class BorderNewXbotRtn(NamedTuple):
	"""Return information for getting new xbots at PMC borders

	Members
	----------
	PmcRtn: PMCRTN
		PMC command return for the border status query command
	xbot_count: int
		Number of new received XBOTs
	xbot_ids: List[int]
		The current IDs of the received XBOTs
	border_ids: List[int]
		The border ID where each xbot was received from
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	xbot_count: int = 0
	xbot_ids: List[int] = None
	border_ids: List[int] = None
	

class WaitUntilTriggerParams(NamedTuple):
	"""public structure for WaitUntil command

	Members
	----------
	delay_secs: float
		When trigger source is set to time delay, this is the delay duration, in seconds
	external_or_fb_input_channel_id: int
		When trigger source is set to Digital Input (external or fieldbus), this is digital input channel ID.
	edge_type: TRIGGEREDGETYPE
		When trigger source is set to Digital Input (external or fieldbus), the edge type or value that will trigger the event
	triggerxbot_id: int
		When trigger source is set to Command Label or Displacement, this is the ID of the XBOT to act as the trigger source
	trigger_cmd_label: int
		When trigger source is set to Command Label, this is Command Label to trigger the event
	trigger_cmd_type: TRIGGERCMDTYPE
		For specifying hte details of a command label trigger.
	0 = motion command label; 1 = Run Macro command label
	cmd_label_trigger_type: TRIGGERCMDLABELTYPE
		When trigger source is set to Command Label,
	CMD_Start means the event will trigger when the command first starts executing,
	CMD_FINISH = after command has finished executing,
	CMD_EXECUTING = at any point during command execution
	displacement_trigger_type: TRIGGERDISPLACEMENTTYPE
		When the trigger source is set to Displacement, the statement AX+BY vs Threshold is evaluated.
	GREATER_THAN means event triggers when AX+BY > Threshold, if is X_ONLY mode, then X > Threshold, in Y_ONLY mode, Y > Threshold.
	LESS_THAN triggers when AX+BY less than Threshold.
	POSITIVE_CROSS triggers when AX+BY is first less than Threshold, then later greater than Threshold.
	NEGATIVE_CROSS triggers when AX+BY is first greater than Threshold, then later less than Threshold.
	displacement_trigger_mode: TRIGGERDISPLACEMENTMODE
		When the trigger source is set to Displacement, this will determine if only the X position is evaluated,
	or if only the Y position is evaluated, or if the position is evaluated as AX+BY
	line_param_ax: float
		When the trigger source is set to Displacement, and the trigger mode is set to AX+BY,
	this will specify the A parameter
	line_param_by: float
		When the trigger source is set to Displacement, and the trigger mode is set to AX+BY,
	this will specify the B parameter
	displacement_threshold_meters: float
		When the trigger source is set to Displacement, this will set the threshold to be compared to
	"""
	delay_secs: float = 0.0
	external_or_fb_input_channel_id: int = 0
	edge_type: TRIGGEREDGETYPE = TRIGGEREDGETYPE(0)
	triggerxbot_id: int = 0
	trigger_cmd_label: int = 0
	trigger_cmd_type: TRIGGERCMDTYPE = TRIGGERCMDTYPE(0)
	cmd_label_trigger_type: TRIGGERCMDLABELTYPE = TRIGGERCMDLABELTYPE(0)
	displacement_trigger_type: TRIGGERDISPLACEMENTTYPE = TRIGGERDISPLACEMENTTYPE(0)
	displacement_trigger_mode: TRIGGERDISPLACEMENTMODE = TRIGGERDISPLACEMENTMODE(0)
	line_param_ax: float = 0.0
	line_param_by: float = 0.0
	displacement_threshold_meters: float = 0.0
	


	

class XBotInfo(NamedTuple):
	"""Basic XBot information

	Members
	----------
	x_pos: float
		X Position in m
	y_pos: float
		Y Position in m
	z_pos: float
		Z Position in m
	rx_pos: float
		Rx pose in rad
	ry_pos: float
		Ry pose in rad
	rz_pos: float
		Rz pose in rad
	xbot_state: XBOTSTATE
		Xbot state
	xbot_id: int
		Xbot ID
	xbot_type: XBOTTYPE
		The type of the XBot
	"""
	x_pos: float = 0.0
	y_pos: float = 0.0
	z_pos: float = 0.0
	rx_pos: float = 0.0
	ry_pos: float = 0.0
	rz_pos: float = 0.0
	xbot_state: XBOTSTATE = XBOTSTATE(0)
	xbot_id: int = 0
	xbot_type: XBOTTYPE = XBOTTYPE(0)

class AllXBotInfo(NamedTuple):
	"""A struct containing a list of basic information for all XBots in the system

	Members
	----------
	PmcRtn: PMCRTN
		PMC Return code for the command
	all_xbot_info_list: List[XBotInfo]
		List of all XBot info
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	all_xbot_info_list: List[XBotInfo] = None	

class XBotStatus(NamedTuple):
	"""full XBot status, including it's position and state

	Members
	----------
	PmcRtn: PMCRTN
		return value for checking the xbot status, the validity of the remaining data in this struct in verified by this field
	xbot_state: XBOTSTATE
		XBot state
	cmd_label: int
		command label of the command the xbot is currently executing
	in_force_mode: bool
		true = xbot is operating in force mode; false = xbot is operating in position mode
	feedback_position_si: List[float]
		position feedback array for 6 DOF, x, y, z in meters, rx, ry, rz in rads
	is_connected_to_group: bool
		true = xbot is connected to a group; false = xbot is not connected to a group
	connected_group_id: int
		if xbot is connected to a group, then it will provide the group ID. otherwise, will provide?
	is_motion_buffer_blocked: bool
		true = xbot's motion buffer is blocked; false = xbot's motion buffer is not blocked
	buffered_motion_count: int
		number of motion commands stored in the xbot's buffer
	stereotype_id: int
		Assigned stereotype ID, 0-255. -1 means stereotype is not supported
	mover_type: MOVERTYPE
		The Type of the XBot
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	xbot_state: XBOTSTATE = XBOTSTATE(0)
	cmd_label: int = 0
	in_force_mode: bool = False
	feedback_position_si: List[float] = None
	is_connected_to_group: bool = False
	connected_group_id: int = 0
	is_motion_buffer_blocked: bool = False
	buffered_motion_count: int = 0
	stereotype_id: int = 0
	mover_type: MOVERTYPE = MOVERTYPE(0)
	

class FlywayPhysicalStatus(NamedTuple):
	"""full return for the Get Flyway Status Command. Includes various temperature measurements and power consumption

	Members
	----------
	PmcRtn: PMCRTN
		return value for checking the xbot status, the validity of the remaining data in this struct in verified by this field
	power_consumption_w: float
		power consumption, in watts
	cpu_temp_c: float
		CPU temperature, in celsius
	amplifier_temp_c: float
		amplifier temperature, in celcius
	motor_temp_c: float
		motor temperature, in celsius
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	power_consumption_w: float = 0.0
	cpu_temp_c: float = 0.0
	amplifier_temp_c: float = 0.0
	motor_temp_c: float = 0.0
	

class XBotIDs(NamedTuple):
	"""Xbot count and ID information

	Members
	----------
	PmcRtn: PMCRTN
		return value for checking the XBOT IDs, the validity of the remaining data in this struct in verified by this field
	xbot_count: int
		Number of detected XBots
	xbot_ids_array: List[int]
		Current IDs of the detected XBOTs
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	xbot_count: int = 0
	xbot_ids_array: List[int] = None
	

class XBotPayloadSettings(NamedTuple):
	"""a single XBOT's payload options

	Members
	----------
	payloadkg: float
		The weight of the payload, in kg
	payload_cg_heightm: float
		the payload's center of gravity, in meters
	payload_dimension_xm: float
		Payload X Dimensions(meters)
	payload_dimension_ym: float
		Payload Y Dimensions(meters)
	"""
	payloadkg: float = 0.0
	payload_cg_heightm: float = 0.0
	payload_dimension_xm: float = 0.0
	payload_dimension_ym: float = 0.0
	

class MoverProperty(NamedTuple):
	"""defines a single mover property

	Members
	----------
	mover_id: int
		ID of the mover to set the property for
	property_id: MOVERPROPERTY
		the index of the mover property
	property_value: float
		the value of the mover property
	"""
	mover_id: int = 0
	property_id: MOVERPROPERTY = MOVERPROPERTY(0)
	property_value: float = 0.0
	

class MoverPropertyReturn(NamedTuple):
	"""full return for the Get Mover Property Command. Contains 8 mover properties

	Members
	----------
	PmcRtn: PMCRTN
		return value for checking the xbot status, the validity of the remaining data in this struct in verified by this field
	valid_properties_count: int
		A count of how many properties are valid. (sometimes less than 8 properties are available, depending on the specified starting property ID).
	mover_properties: List[MoverProperty]
		group information, all 0 if group incorrect or operating on all groups
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	valid_properties_count: int = 0
	mover_properties: List[MoverProperty] = None
	

class XBotForceSetting(NamedTuple):
	"""Settings for the Open-Loop Force Mode

	Members
	----------
	fx: float
		Force in X (N)
	fy: float
		Force in Y (N)
	fz: float
		Force in Z (N)
	tx: float
		Torque in Rx (Nm)
	ty: float
		Torque in Ry (Nm)
	tz: float
		Torque in Rz (Nm)
	"""
	fx: float = 0.0
	fy: float = 0.0
	fz: float = 0.0
	tx: float = 0.0
	ty: float = 0.0
	tz: float = 0.0
	

class ForceModeAxes(NamedTuple):
	"""Defines which axes to enable force mode for

	Members
	----------
	x: bool
		X-Axis
	y: bool
		Y-Axis
	z: bool
		Z-Axis
	rx: bool
		Rx-Axis
	ry: bool
		Ry-Axis
	rz: bool
		Rz-Axis
	"""
	x: bool = False
	y: bool = False
	z: bool = False
	rx: bool = False
	ry: bool = False
	rz: bool = False
	

class ZoneStatusReturn(NamedTuple):
	"""full return for the Get Zone Status Command. Contains Zone information

	Members
	----------
	PmcRtn: PMCRTN
		return value for checking the zone status, the validity of the remaining data in this struct in verified by this field
	zone_state: ZONESTATE
		A count of how many properties are valid. (sometimes less than 8 properties are available, depending on the specified starting property ID).
	xbot_count: int
		Number of XBots inside the zone
	xbot_ids: List[int]
		list of XBot IDs of XBots inside the zone
	xbot_count_on_border: int
		Number of XBots on the zone's border
	xbot_ids_on_border: List[int]
		list of XBot IDs of XBots on the zone's border
	speed_override_ratio: float
		Speed Override Ratio of the Zone
	acceleration_override_ratio: float
		Acceleration Override Ratio of the Zone
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	zone_state: ZONESTATE = ZONESTATE(0)
	xbot_count: int = 0
	xbot_ids: List[int] = None
	xbot_count_on_border: int = 0
	xbot_ids_on_border: List[int] = None
	speed_override_ratio: float = 0.0
	acceleration_override_ratio: float = 0.0
	

class MoverStereotypeData(NamedTuple):
	"""mover stereotype definition

	Members
	----------
	performance_level: int
		The control performance level[0-3], 0 = most conservative level, 3 = most aggresive level
	payloadkg: float
		The weight of the payload, in kg
	payload_positive_xm_from_xbot_center: float
		Payload size from center of the XBOT, in +X direction (meters)
	payload_negative_xm_from_xbot_center: float
		Payload size from center of the XBOT, in -X direction (meters)
	payload_positive_ym_from_xbot_center: float
		Payload size from center of the XBOT, in +Y direction (meters)
	payload_negative_ym_from_xbot_center: float
		Payload size from center of the XBOT, in -Y direction (meters)
	payload_cg_xm: float
		the payload's center of gravity in the x direction, in meters
	payload_cg_ym: float
		the payload's center of gravity in the y direction, in meters
	payload_cg_zm: float
		the payload's center of gravity in the z direction, in meters
	emergency_deceleration: float
		the emergency deceleration in meters per second square
	"""
	performance_level: int = 0
	payloadkg: float = 0.0
	payload_positive_xm_from_xbot_center: float = 0.0
	payload_negative_xm_from_xbot_center: float = 0.0
	payload_positive_ym_from_xbot_center: float = 0.0
	payload_negative_ym_from_xbot_center: float = 0.0
	payload_cg_xm: float = 0.0
	payload_cg_ym: float = 0.0
	payload_cg_zm: float = 0.0
	emergency_deceleration: float = 0.0
	

class MoverStereotypeDefinitionReturn(NamedTuple):
	"""full return for the Get Mover Stereotype Command.

	Members
	----------
	PmcRtn: PMCRTN
		return value for checking the xbot status, the validity of the remaining data in this struct in verified by this field
	stereotype_data: MoverStereotypeData
		mover stereotype data
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	stereotype_data: MoverStereotypeData = MoverStereotypeData(0)
	

class ReadAssignedStereotypeReturn(NamedTuple):
	"""full return for the read assigned mover stereotype Command.

	Members
	----------
	PmcRtn: PMCRTN
		return value for checking the xbot status, the validity of the remaining data in this struct in verified by this field
	assigned_stereotype_id: int
		ID of the assigned mover stereotype
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	assigned_stereotype_id: int = 0
	

class PayloadWeighingReturn(NamedTuple):
	"""full return for the Get Mover Property Command. Contains 8 mover properties

	Members
	----------
	PmcRtn: PMCRTN
		return value for checking the xbot status, the validity of the remaining data in this struct in verified by this field
	weight_kg: float
		Measured weight, in kg
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	weight_kg: float = 0.0
	

class PayloadRtn(NamedTuple):
	"""return struct for get payload settings commands, includes PMC return + PayloadSettings

	Members
	----------
	PmcRtn: PMCRTN
		PMC return for the motion command
	payload_settings: XBotPayloadSettings
		an xbot's payload settings
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	payload_settings: XBotPayloadSettings = XBotPayloadSettings(0)
	

class MotionBufferStatus(NamedTuple):
	"""a single XBOT's motion buffer status

	Members
	----------
	is_buffer_blocked: bool
		true is xbot buffer is currently blocked, false is buffer is unblocked
	buffered_motion_count: int
		number of motions commands stored in the xbot's buffer. If xbot ID = 0, the reply will be 0
	first_buffered_motion_cmd_label: int
		command label of the first command in the buffer, it is the next command that will be executed by the xbot.
	last_buffered_motion_cmd_label: int
		command label of the last command in the buffer, this is the command that is most recently added to the motion buffer.
	xbot_id: int
		the ID of the xbot that this return is describing
	"""
	is_buffer_blocked: bool = False
	buffered_motion_count: int = 0
	first_buffered_motion_cmd_label: int = 0
	last_buffered_motion_cmd_label: int = 0
	xbot_id: int = 0
	

class MotionBufferReturn(NamedTuple):
	"""full return of the motion buffer command

	Members
	----------
	PmcRtn: PMCRTN
		return value for checking the xbot status, the validity of the remaining data in this struct in verified by this field
	motion_buffer_status: MotionBufferStatus
		the status of the xbot's motion buffer
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	motion_buffer_status: MotionBufferStatus = MotionBufferStatus(0)
	


class MotionMacroStatus(NamedTuple):
	"""a single XBOT's motion macro status

	Members
	----------
	macro_id: int
		the ID of the macro that this return is describing
	macro_state: int
		0 = macro is not saved (cannot be run); 2 = macro is saved (ready to run)
	stored_commands_count: int
		the number of commands stored in this macro
	"""
	macro_id: int = 0
	macro_state: int = 0
	stored_commands_count: int = 0
	

class MotionMacroReturn(NamedTuple):
	"""full return of the motion macro

	Members
	----------
	PmcRtn: PMCRTN
		return value of the motion macro command
	motion_macro_status: MotionMacroStatus
		the status of the motion macro
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	motion_macro_status: MotionMacroStatus = MotionMacroStatus(0)
	


class GroupInformation(NamedTuple):
	"""group information

	Members
	----------
	group_id: int
		The ID of the group this return is describing
	group_status: int
		0 = group is disconnected, 1 = group is connected
	group_members_count: int
		number of xbots in this group
	group_members_ids: List[int]
		the IDs of the xbots in this group
	"""
	group_id: int = 0
	group_status: int = 0
	group_members_count: int = 0
	group_members_ids: List[int] = None

class GroupCtrlReturn(NamedTuple):
	"""full return for the group control command

	Members
	----------
	PmcRtn: PMCRTN
		return value for checking the xbot status, the validity of the remaining data in this struct in verified by this field
	group_info: GroupInformation
		group information, all 0 if group incorrect or operating on all groups
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	group_info: GroupInformation = GroupInformation(0)

class CamAxisDataClass(NamedTuple):
	"""information required to setup 1 axis of the slave xbot's cam trajectory.

	Members
	----------
	masterx_id: int
		ID of the master XBOT
	master_axis_id: AXISNAMES
		Axis of the master XBOT to track
	slave_axis_id: AXISNAMES
		Axis of the slave XBOT used to follow the CAM
	cam_id: int
		ID of the Cam
	"""
	masterx_id: int = 0
	master_axis_id: AXISNAMES = AXISNAMES(0)
	slave_axis_id: AXISNAMES = AXISNAMES(0)
	cam_id: int = 0
	

class CamAxisDataClassExtended(NamedTuple):
	"""information required to setup 1 axis of the slave xbot's cam trajectory.

	Members
	----------
	masterx_id: int
		ID of the master XBOT
	master_axis_id: AXISNAMES
		Axis of the master XBOT to track
	slave_axis_id: AXISNAMES
		Axis of the slave XBOT used to follow the CAM
	cam_id: int
		ID of the Cam
	cam_mode: CAMMODE
		operating mode of the cam, can set cam to automatically repeat
	master_axis_scaling: float
		Scaling factor for master axis position interval
	slave_axis_scaling: float
		Scaling factor for slave axis position values
	master_axis_offset_m: float
		The offset between the start of master axis and the specified origin point, in meters
	master_axis_offset_mode: POSITIONMODE
		In absolute mode, the origin position of the cam master axis is the same as the system origin. In relative mode, the origin position of the cam master axis is the same as the current position of the master xbot when the cam was activated
	slave_axis_offset_m: float
		The offset between the start of slave axis and the specified origin point, in meters
	slave_axis_offset_mode: POSITIONMODE
		In absolute mode, the origin position of the cam slave axis is the same as the system origin. In relative mode, the origin position of the cam slave axis is the same as the current position of the slave xbot when the cam was activated
	master_axis_ratchet_direction: CAMRATCHETDIRECTION
		ratchet direction of the cam master axis. choose whether cam is engage whether the master cam position is increasing or decreasing, only engaged when it's increasing, or only when it's decreasing
	"""
	masterx_id: int = 0
	master_axis_id: AXISNAMES = AXISNAMES(0)
	slave_axis_id: AXISNAMES = AXISNAMES(0)
	cam_id: int = 0
	cam_mode: CAMMODE = CAMMODE(0)
	master_axis_scaling: float = 0.0
	slave_axis_scaling: float = 0.0
	master_axis_offset_m: float = 0.0
	master_axis_offset_mode: POSITIONMODE = POSITIONMODE(0)
	slave_axis_offset_m: float = 0.0
	slave_axis_offset_mode: POSITIONMODE = POSITIONMODE(0)
	master_axis_ratchet_direction: CAMRATCHETDIRECTION = CAMRATCHETDIRECTION(0)
	

class QueueDefinition(NamedTuple):
	"""Define the queue region

	Members
	----------
	area_left_xm: float
		starting x coordinate of the queue area, in meters
	area_bottom_ym: float
		starting y coordinate of the queue area, in meters
	area_right_xm: float
		ending x coordinate of the queue area, in meters
	area_top_ym: float
		ending y coordinate of the queue area, in meters
	entry_location: AREASELECTION
		entry area of the queue region
	exit_location: AREASELECTION
		exit area of the queue region
	max_xbot_x_sizem: float
		size of the largest Xbot allowed in the queue, x dimension, in meters
	max_xbot_y_sizem: float
		size of the largest xbot allowed in the queue, y dimension, in meters
	max_speed_in_queue: float
		max speed used by the queue management to move the XBots
	max_accel_in_queue: float
		max acceleration used by the queue management to move the XBots
	"""
	area_left_xm: float = 0.0
	area_bottom_ym: float = 0.0
	area_right_xm: float = 0.0
	area_top_ym: float = 0.0
	entry_location: AREASELECTION = AREASELECTION(0)
	exit_location: AREASELECTION = AREASELECTION(0)
	max_xbot_x_sizem: float = 0.0
	max_xbot_y_sizem: float = 0.0
	max_speed_in_queue: float = 0.0
	max_accel_in_queue: float = 0.0
	

class AutoLoadZoneDefinition(NamedTuple):
	"""Define the auto load region

	Members
	----------
	boundary_centerx_m: float
		center of the zone at the boundary of the flyway, x position, meters
	boundary_centery_m: float
		center of the zone at the boundary of the flyway, y position, meters
	zone_lengthm: float
		Length of the zone, meters
	zone_widthm: float
		Width of the zone, meters
	zone_type: ALZONETYPE
		loading zone = adding XBot to Flyway. unloading zone = removing XBot from flyway
	unloading_mode: ALZONEUNLOADMODE
		stop before unloading, or unload without stopping
	max_xbot_x_sizem: float
		x size of the Xbot to load / unload, meters
	max_xbot_y_sizem: float
		y size of the Xbot to load / unload, meters
	max_speed: float
		max speed used to load or unload XBots
	max_accel: float
		max acceleration used to load or unload XBots
	max_heightm: float
		max detection height for manual loading, meters
	"""
	boundary_centerx_m: float = 0.0
	boundary_centery_m: float = 0.0
	zone_lengthm: float = 0.0
	zone_widthm: float = 0.0
	zone_type: ALZONETYPE = ALZONETYPE(0)
	unloading_mode: ALZONEUNLOADMODE = ALZONEUNLOADMODE(0)
	max_xbot_x_sizem: float = 0.0
	max_xbot_y_sizem: float = 0.0
	max_speed: float = 0.0
	max_accel: float = 0.0
	max_heightm: float = 0.0
	


	

class QueueStatus(NamedTuple):
	"""Basic Queue Status information

	Members
	----------
	entry_ready_to_receive_xbot: bool
		The entry area is empty and ready to receive an XBot
	xbot_available_at_exit: bool
		there is an XBot available at the exit location
	xbot_id_at_exit: int
		ID of the XBot available at the exit location
	queue_entry_xposm: float
		center x position of the entry area of the queue
	queue_entry_yposm: float
		center y position of the entry area of the queue
	"""
	entry_ready_to_receive_xbot: bool = False
	xbot_available_at_exit: bool = False
	xbot_id_at_exit: int = 0
	queue_entry_xposm: float = 0.0
	queue_entry_yposm: float = 0.0

class QueueStatusReturn(NamedTuple):
	"""the return value for the GetQueueStatus Command

	Members
	----------
	PmcRtn: PMCRTN
		return value for checking the queue status, the validity of the remaining data in this struct in verified by this field
	queue_status: QueueStatus
		the status of the queue
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	queue_status: QueueStatus = QueueStatus(0)

	

class QueueInfo(NamedTuple):
	"""information about the queue

	Members
	----------
	entry_ready_to_receive_xbot: bool
		The entry area is empty and ready to receive an XBot
	xbot_available_at_exit: bool
		there is an XBot available at the exit location
	xbot_count: int
		number of XBots being managed by the Queue
	queued_xbots_ids: List[int]
		Array of XBot IDs of the XBots being managed by the Queue
	"""
	entry_ready_to_receive_xbot: bool = False
	xbot_available_at_exit: bool = False
	xbot_count: int = 0
	queued_xbots_ids: List[int] = None


class QueueInfoReturn(NamedTuple):
	"""the return value for the GetQueueInfo Command

	Members
	----------
	PmcRtn: PMCRTN
		return value for checking the queue info, the validity of the remaining data in this struct in verified by this field
	queue_info: QueueInfo
		detailed info of the queue
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	queue_info: QueueInfo = QueueInfo(0)	

class NoiseDefinition(NamedTuple):
	"""Define the noise parameters

	Members
	----------
	axis_id: AXISNAMES
		Axis ID (1-7)
	type: NOISETYPE
		Type of noise (0: sinusoidal wave; 1: white noise) (not implemented)
	magnitude_force: float
		Magnitide of noise force. N in x, y, z directions. Nm in Rx, Ry, Rz
	frequency_hz: float
		Freuqnecy of noise in Hz
	phase_radians: float
		Phase shift in radians
	duration_sec: float
		Duration in second
	delay_sec: float
		Delay in seconds
	"""
	axis_id: AXISNAMES = AXISNAMES(0)
	type: NOISETYPE = NOISETYPE(0)
	magnitude_force: float = 0.0
	frequency_hz: float = 0.0
	phase_radians: float = 0.0
	duration_sec: float = 0.0
	delay_sec: float = 0.0

	

class AutoLoadZoneStatus(NamedTuple):
	"""auto-loading zone status information

	Members
	----------
	zone_state: ALZONESTATE
		whether the zone is undefined, unloading, or loading state
	loaded_xbot_id: int
		ID of the XBot loaded at the loading zone
	ready_for_next_xbot: bool
		unloading zone ready for next XBot means it is ready to receive another XBot to send to the external device
	loading zone ready for next XBot means it is ready to receive another XBot from the external device
	xbot_count: int
		number of XBots inside the zone
	unloading_entry_xposm: float
		x position of the unloading point in an unloading zone
	unloading_entry_yposm: float
		y position of the unloading point in an unloading zone
	"""
	zone_state: ALZONESTATE = ALZONESTATE(0)
	loaded_xbot_id: int = 0
	ready_for_next_xbot: bool = False
	xbot_count: int = 0
	unloading_entry_xposm: float = 0.0
	unloading_entry_yposm: float = 0.0
	
	

class AutoLoadZoneStatusReturn(NamedTuple):
	"""the return value for the GetQueueStatus Command

	Members
	----------
	PmcRtn: PMCRTN
		return value for checking the queue status, the validity of the remaining data in this struct in verified by this field
	al_zone_status: AutoLoadZoneStatus
		the status of the auto loading zone
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	al_zone_status: AutoLoadZoneStatus = AutoLoadZoneStatus(0)

class StarWheelDefinition(NamedTuple):
	"""Define the star wheel

	Members
	----------
	disc_radius: float
		Disc radius in meters
	max_disc_speed: float
		Max disc rotation speed in radians/sec (must be positive)
	max_xbot_acc: float
		Max xbot acceleration in meters/sec^2 (must be positive)
	sync_angle_begin: float
		Start of sync section in radians (if CCW must be less than end angle, if CW must be greater than end angle)
	sync_angle_end: float
		End of sync section in ratdians (if CCW must be greater than end angle, if CW must be less than end angle)
	disc_centerx_: float
		X coordinate of disc center in meters
	disc_centery_: float
		Y coordinate of disc center in meters
	start_location_x: float
		X coordinate of starting location in meters
	start_location_y: float
		Y coordinate of starting location in meters
	end_location_x: float
		X coordinate of ending location in meters
	end_location_y: float
		Y coordinate of ending location in meters
	vial_locations: List[float]
		locations of vials on the disc in radians (must be 0-2PI);
	num_vials: int
		number of vials on the disc (less than or equal to 100)
	direction: int
		Direction of disc rotation (0 = clockwise,1 = counterclockwise)
	masterx_id: int
		ID of master xbot (must be virtual 100-127)
	"""
	disc_radius: float = 0.0
	max_disc_speed: float = 0.0
	max_xbot_acc: float = 0.0
	sync_angle_begin: float = 0.0
	sync_angle_end: float = 0.0
	disc_centerx_: float = 0.0
	disc_centery_: float = 0.0
	start_location_x: float = 0.0
	start_location_y: float = 0.0
	end_location_x: float = 0.0
	end_location_y: float = 0.0
	vial_locations: List[float] = None
	num_vials: int = 0
	direction: int = 0
	masterx_id: int = 0
	

class StarWheelStatus(NamedTuple):
	"""Status of star wheel

	Members
	----------
	state: int
		Star wheel state: 0 = unassigned, 1 = assigned
	start_location_x: float
		Start location X coordinate in meters
	start_location_y: float
		Start location Y coordinate in meters
	end_location_x: float
		End location X coordinate in meters
	end_location_y: float
		End location Y coordinate in meters
	entrance_status: int
		Entrance status: 0 - not ready to receive new xbot, 1 - ready to receive new xbot
	exit_status: int
		Exit status: 0 - xbot is not ready to fetch, 1 - xbot is ready to fetch
	exit_xid: int
		Xbot ID to fetch
	"""
	state: int = 0
	start_location_x: float = 0.0
	start_location_y: float = 0.0
	end_location_x: float = 0.0
	end_location_y: float = 0.0
	entrance_status: int = 0
	exit_status: int = 0
	exit_xid: int = 0
	

class StarWheelStatusRtn(NamedTuple):
	"""Star wheel status return wrapper

	Members
	----------
	PmcRtn: PMCRTN
		Return code
	wheel_status: StarWheelStatus
		Star wheel status
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	wheel_status: StarWheelStatus = StarWheelStatus(0)
	

class SixDOFInfo(NamedTuple):
	"""6DOF information struct

	Members
	----------
	x: float
		X axis data
	y: float
		Y axis data
	z: float
		Z axis data
	rx: float
		X Rotation axis data
	ry: float
		Y Rotation axis data
	rz: float
		Z Rotation axis data
	"""
	x: float = 0.0
	y: float = 0.0
	z: float = 0.0
	rx: float = 0.0
	ry: float = 0.0
	rz: float = 0.0
	

class SectorStatusReturn(NamedTuple):
	"""full return for the Get Sector Status Command. Contains Sone information

	Members
	----------
	PmcRtn: PMCRTN
		return value for checking the sector status, the validity of the remaining data in this struct is verified by this field
	sector_state: SECTORSTATE
		The state of the sector
	xbot_count: int
		Number of XBots inside the sector
	xbot_ids: List[int]
		list of XBot IDs of XBots inside the sector
	xbot_count_on_border: int
		Number of XBots on the sector's border
	xbot_ids_on_border: List[int]
		list of XBot IDs of XBots on the sector's border
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	sector_state: SECTORSTATE = SECTORSTATE(0)
	xbot_count: int = 0
	xbot_ids: List[int] = None
	xbot_count_on_border: int = 0
	xbot_ids_on_border: List[int] = None
	

class ReadExternalSignalRtn(NamedTuple):
	"""Read Externl Signal Command's Return

	Members
	----------
	PmcRtn: PMCRTN
		return value the Read External Signal command, the validity of the remaining data in this struct is verified by this field
	signal: bool
		Signal
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	signal: bool = False
	

class GetPMCTimeRtn(NamedTuple):
	"""Read Get PMC Time Command's Return

	Members
	----------
	PmcRtn: PMCRTN
		return value the Read External Signal command, the validity of the remaining data in this struct is verified by this field
	pmc_time: datetime.datetime
		PMC Time
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	pmc_time: datetime.datetime = datetime.datetime.min
	

class AvailabilityStatus(NamedTuple):
	"""A struct containing whether a station or bay is available

	Members
	----------
	PmcRtn: PMCRTN
		PMC Return code for the command
	is_available: bool
		Whether the station or bay is available or not
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	is_available: bool = False
	

class StationFullStatus(NamedTuple):
	"""A struct containing whether a station is full

	Members
	----------
	PmcRtn: PMCRTN
		PMC Return code for the command
	is_full: bool
		Whether the station is full or not
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	is_full: bool = False
	

class BayXbotId(NamedTuple):
	"""A struct containing the xbot ID currently in a bay

	Members
	----------
	PmcRtn: PMCRTN
		PMC Return code for the command
	xbot_id: int
		Xbot ID currently in the station
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	xbot_id: int = 0
	

class TargetStation(NamedTuple):
	"""A struct target station info

	Members
	----------
	PmcRtn: PMCRTN
		PMC Return code for the command
	station_id: int
		Target station
	bay_id: int
		Target bay
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	station_id: int = 0
	bay_id: int = 0
	

class StationXbotIds(NamedTuple):
	"""A struct containing xbot IDs currently in a station

	Members
	----------
	PmcRtn: PMCRTN
		PMC Return code for the command
	station_id: int
		Station ID
	bay_xbot_map: dict[int, int]
		Key = bayID
	Value = xbotID inside of bay bayID, -1 if no xbot
	xbot_ids: List[int]
		Unique xbot IDs > 0 currently in the station
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	station_id: int = 0
	bay_xbot_map: dict[int, int] = None
	xbot_ids: List[int] = None
	

class AllStationXbotIds(NamedTuple):
	"""A struct containing xbot IDs currently in all stations

	Members
	----------
	PmcRtn: PMCRTN
		PMC Return code for the command
	station_xbot_ids: List[StationXbotIds]
		XbotIDs inside all stations
	"""
	PmcRtn: PMCRTN = PMCRTN(0)
	station_xbot_ids: List[StationXbotIds] = None
	
