from enum import IntEnum
from typing import List
from typing import NamedTuple
from enum import Enum
import PMCLIB


class PmcError(Exception):
    """PMC Error Exception
    """

    def __init__(self, *args: object) -> None:
        super().__init__(*args)


class XbotType(IntEnum):
    """_summary_

    Options
    ----------
    M3_06 :
        M3-06 120mm x 120mm
    M3_08 :
        M3-08 180mm x 120mm
    M3_09 :
        M3-09 120mm x 240mm
    M3_10 :
        M3-10 180mm x 180mm
    M3_11 :
        M3-11 210mm x 180mm
    M3_12 :
        M3-12 210mm x 210mm
    M3_13 :
        M3-13 240mm x 240mm
    M3_17 :
        M3-17 300mm x 300mm
    M3_18 :
        M3-18 330mm x 330mm
    """
    M3_06 = 0,
    M3_08 = 2,
    M3_09 = 4,
    M3_10 = 6,
    M3_11 = 8,
    M3_12 = 12,
    M3_13 = 14,
    M3_18 = 20,


class XbotState(IntEnum):
    """XBot state

    Options
    ----------
    XBOT_PREVIEW :
        Reserved
    XBOT_UNKNOWN :
        unable to determine XBOT state
    XBOT_UNDETECTED :
        XBot not detected by the PMC
    XBOT_DISCOVERING :
        XBOT is being scanned for absolute id
    XBOT_LANDED :
        XBOT is landed
    XBOT_IDLE :
        XBOT is idling (levitated)
    XBOT_DISABLED :
        XBOT is disabled
    XBOT_MOTION :
        XBOT is in motion
    XBOT_WAIT :
        XBOT is waiting for a trigger
    XBOT_STOPPING :
        XBOT is attempting to stop
    XBOT_OBSTACLE_DETECTED :
        XBOT detected an obstacle and is waiting for obstacle to clear
    XBOT_HOLDPOSITION :
        XBOT is hold position due excessive error during motion
    XBOT_STOPPED :
        XBOT stopped and will not automatically resume
    XBOT_RESERVED :
        Reserved
    XBOT_RESERVED1 :
        Reserved
    XBOT_RESERVED2 :
        Reserved
    XBOT_ERROR :
        XBot is error handling
    XBOT_UNINSTALLED :
        XBot is not installed
    """
    XBOT_PREVIEW = -2,
    XBOT_UNKNOWN = -1,
    XBOT_UNDETECTED = 0,
    XBOT_DISCOVERING = 1,
    XBOT_LANDED = 2,
    XBOT_IDLE = 3,
    XBOT_DISABLED = 4,
    XBOT_MOTION = 5,
    XBOT_WAIT = 6,
    XBOT_STOPPING = 7,
    XBOT_OBSTACLE_DETECTED = 8,
    XBOT_HOLDPOSITION = 9,
    XBOT_STOPPED = 10,
    XBOT_RESERVED = 11,
    XBOT_RESERVED1 = 12,
    XBOT_RESERVED2 = 13,
    XBOT_ERROR = 14,
    XBOT_UNINSTALLED = 15,


class PositionMode(IntEnum):
    """ Position mode

    Options
    -------
    ABSOLUTE :
        Absolute position mode
    RELATIVE :
        Relative position mode
    """
    ABSOLUTE = 0,
    RELATIVE = 1,


class LinearPathType(IntEnum):
    """ Linear path type

    Options
    -------
    DIRECT :
        Move directly to position
    XTHENY :
        Move in X and then Y to target
    YTHENX :
        Move in Y and then X to target
    """
    DIRECT = 0,
    XTHENY = 1,
    YTHENX = 2,


class RotationMode(IntEnum):
    """ Rotation motion type

    Options
    -------
    NO_ANGLE_WRAP :
        Move directly to target Rz position
    WRAP_TO_2PI_CCW :
        Wrap current and target angle to [0, 2PI], rotate in the counter-clockwise direction
    WRAP_TO_2PI_CW :
        Wrap current and target angle to [0, 2PI], rotate in the clockwise direction
    """
    NO_ANGLE_WRAP = 0,
    WRAP_TO_2PI_CCW = 1,
    WRAP_TO_2PI_CW = 2

class LevitateOptions(IntEnum):
    """Levitation options

    Options
    ----------
    LAND :
        Land XBOT
    LEVITATE :
        Levitate XBOT
    """
    LAND = 0,
    LEVITATE = 1,


class PmcStatus(IntEnum):
    """ PMC Status

    Options
    -------
    PMC_UNKNOWN :
        Unable to determine PMC Status
    PMC_BOOTING :
        PMC is booting up
    PMC_INACTIVE :
        PMC is inactive (XBOTs deactivated)
    PMC_ACTIVATING :
        PMC is starting to activate
    PMC_DISCOVERY :
        Movers are scanning for Absolute ID
    PMC_SERVICE :
        PMC in service mode
    PMC_FULLCTRL :
        PMC in fully controlled mode
    PMC_INTELLIGENTCTRL :
        PMC in intelligent control mode
    PMC_DEACTIVATING :
        PMC is deactivating
    PMC_ERRORHANDLING :
        PMC is handling an error and recording snapshots
    PMC_ERROR :
        PMC is in the error state
    """
    PMC_UNKNOWN = -1,
    PMC_BOOTING = 0,
    PMC_INACTIVE = 1,
    PMC_ACTIVATING = 2,
    PMC_DISCOVERY = 3,
    PMC_SERVICE = 4,
    PMC_FULLCTRL = 5,
    PMC_INTELLIGENTCTRL = 6,
    PMC_DEACTIVATING = 7,
    PMC_ERRORHANDLING = 8,
    PMC_ERROR = 9,


class FeedbackType(IntEnum):
    """ Information to get from mover

    Options
    ----------
    POSITION : 
        Feedback Position
    FORCE : 
        Feedback Force
    REFERENCE :
        Reference Position
    TARGET :
        Buffered Target position
    REF_VELOCITY : 
        Reference velocity
    """
    POSITION = 0,
    FORCE = 1,
    REFERENCE = 2,
    TARGET = 5,
    REF_VELOCITY = 6


class MotionMacroOptions(IntEnum):
    """ Motion Macro State

    Options
    ----------
    CLEAR_MACRO :
        Clear the motion macro of commands
    SAVE_MACRO :
        Finish editting the motion macro, and save it.
    QUERY_MACRO :
        Query the motion macro status
    """
    CLEAR_MACRO = 0,
    SAVE_MACRO = 2,
    QUERY_MACRO = 4


class FlywayPhysicalStatus(NamedTuple):
    """Flyway physical status

    Members
    ----------
    power_consumption : float :
        power consumption, in watts
    cpu_temp : float :
        CPU temperature, in celsius
    amlifier_temp : float :
        amplifier temperature, in celcius
    motor_temp : float :
        motor temperature, in celsius
    """
    power_consumption: float
    cpu_temp: float
    amlifier_temp: float
    motor_temp: float


class XbotStatus(NamedTuple):
    """full XBot status, including it's position and state

    Members
    ----------
    xbot_state : XBotState :
        XBot state
    cmd_label : int :
        command label of the command the xbot is currently executing, unsigned 2 bytes
    force_mode : bool :
        true = xbot is operating in force mode; false = xbot is operating in position mode
    feedback_position_si : List[float] :
        position feedback array for 6 DOF, x, y, z in meters, rx, ry, rz in rads
    connected_to_group : bool :
        true = xbot is connected to a group; false = xbot is not connected to a group
    connected_group_id : int :
        if xbot is connected to a group, then it will provide the group ID.
    motion_buffer_blocked : bool :
        true = xbot's motion buffer is blocked; false = xbot's motion buffer is not blocked
    buffered_motion_count : int :
        number of motion commands stored in the xbot's buffer
    stereotype_id : int :
        Assigned stereotype ID, 0-255. -1 means stereotype is not supported
    xbot_type : XbotType :
        The Type of the XBot
    """
    xbot_state: XbotState
    cmd_label: int
    force_mode: bool
    feedback_position_si: List[float]
    connected_to_group: bool
    connected_group_id: int
    motion_buffer_blocked: bool
    buffered_motion_count: int
    stereotype_id: int
    xbot_type: XbotType


class XbotInfo(NamedTuple):
    """stores basic information about one XBot

    Members
    ----------
    x_pos : float :
        X Position in m
    y_pos : float :
        Y Position in m
    z_pos : float :
        Z Position in m
    rx_pos : float :
        Rx Position in rad
    ry_pos : float :
        Ry Position in rad
    rz_pos : float :
        Rz Position in rad
    xbot_state : XbotState :
        Xbot state
    xbot_id : int :
        Xbot ID
    xbot_type : XbotType :
        The type of the XBot
    """
    x_pos: float
    y_pos: float
    z_pos: float
    rx_pos: float
    ry_pos: float
    rz_pos: float
    xbot_state: XbotState
    xbot_id: int
    xbot_type: XbotType


class MotionMacroStatus(NamedTuple):
    """Motion Macro status

    Members
    ----------
    macro_id : int :
        the ID of the macro that this tuple is describing
    macro_state : int :
        0 = macro is not saved (cannot be run); 2 = macro is saved (ready to run)
    stored_commands_count :int :
        the number of commands stored in this macro
    """
    macro_id: int
    macro_state: int
    stored_commands_count: int


def assert_type(checkvar, checkType: type, varName: str = ""):
    """Assert the input variable is of the correct type

    Parameters
    ----------
    var : Any
        Variable to check
    checkType : type
        Type that the variable is asserted to be
    varName : str
        Name of the variable
    """

    if type(checkvar) is not checkType:
        raise TypeError(
            f"{varName} expected {checkType}, got {type(checkvar)}")
