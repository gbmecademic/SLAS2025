"""
Planar Motor API data-types
"""

from enum import IntEnum
from typing import Literal
 
class PmcError(Exception):
    """_summary_

    Args:
        Exception (_type_): _description_
    """
    def __init__(self, *args: object) -> None:
        super().__init__(*args)  
        

class PositionMode(IntEnum):
    """
    Specify the positioning mode.
    ABSOLUTE = Absolute positiong
    RELATIVE = Relative positioning
    """
    ABSOLUTE = 0,
    RELATIVE = 1,
    